﻿
#Loading Assemblies
[void][System.Reflection.Assembly]::LoadWithPartialName('System.Windows.Forms')
[void][System.Reflection.Assembly]::LoadWithPartialName('System.Drawing')
####################

<# Editable Varaibles #>
$Folder_PBAs = '\\newton\admin\SysAdmin Powershell Module\Scripts\-ARCHIVE\Get-ServerVolumeSpace\PBA-List.txt'
$Folder_Results = '\\newton\admin\SysAdmin Powershell Module\Scripts\Get-ServerVolumeSpace\Exports\'
<# End Editable Variables #>

<# Form Shortcut Variables #>
$Location = 'System.Drawing.Point'
$Size = 'System.Drawing.Size'
$Form = 'System.Windows.Forms.Form'
$PictureBox = 'System.Windows.Forms.PictureBox'
$Button = 'System.Windows.Forms.Button'
$CheckBox = 'System.Windows.Forms.CheckBox'
$ComboBox = 'System.Windows.Forms.ComboBox'
$ListBox = 'System.Windows.Forms.ListBox'
$ListView = 'System.Windows.Forms.ListView'
$CheckedListBox = 'System.Windows.Forms.CheckedListBox'
$RadioButton = 'System.Windows.Forms.RadioButton'
$TextBox = 'System.Windows.Forms.TextBox'
$RichTextBox = 'System.Windows.Forms.RichTextBox'
$Label = 'System.Windows.Forms.Label'
$Timer = 'System.Windows.Forms.Timer'
$ProgressBar = 'System.Windows.Forms.ProgressBar'
<# End Form Shortcut Variables #>

<# Font Sizes #>
$Font_Primary = [System.Drawing.Font]::new("Cosmic Sans", 11, [System.Drawing.FontStyle]::Bold)
$Font_Secondary = [System.Drawing.Font]::new("Cosmic Sans", 10, [System.Drawing.FontStyle]::Bold)
<# End Font Sizes #>

<# Script Arrays #>
$Script:CurrentBars = [System.Collections.Generic.List[System.Object]]@()
$Script:ExportData = [System.Collections.Generic.List[System.Object]]@()
<# End Script Arrays #>

#region <# Create Object Functions #>
Function Add-Bar($name,$posx,$posy,$value) {
    New-Variable -Name $name -Value $bname # - Creates the variable
    $bname = New-Object $ProgressBar ; $bname.Size = New-Object $Size(200,50) ; $bname.Location = New-Object $Location($posx,$posy) # - Creates the Bar and size/location
    $bname.BackColor = 'Black' # - Sets the background color of the bar
    If($value -lt 70){$bname.ForeColor = 'Green'} ElseIf($value -gt 69 -and ($value -lt 90)){$bname.ForeColor = 'Yellow'} ElseIf($value -ge 90){$bname.ForeColor = 'Red'} # - Sets the bar ForeColor
    $bname.Style = 'Continuous' # - Sets the bar to be continuously a single color
    $bname.Value = $value # - Sets the value of the bar
    $bname
}

Function Add-Label($name,$xsize,$ysize,$posx,$posy,$text,$fixed3d) {
    New-Variable -Name $name -Value $lname # - Creates the variable
    If($xsize -eq $null){$xsize = 200} If($ysize -eq $null){$ysize = 30} # - Makes sure a defuault size is set
    $lname = New-Object $Label ; $lname.Size = New-Object $Size($xsize,$ysize) ; $lname.Location = New-Object $Location($posx,$posy) # - Creates the label and size/location
    If($fixed3d -eq $null){$lname.BorderStyle = 'Fixed3D'} # - Added the option for Fixed3D Border
    $lname.BackColor = 'Gray' # Sets the background color
    $lname.Font = $Font_Secondary ; $lname.TextAlign = 'MiddleCenter' ; $lname.Text = $text # - Sets the text options
    $lname
}

Function Add-Button($name,$xsize,$ysize,$xpos,$ypos,$text) {
    New-Variable -Name $name -Value $bname # - Creates the variable
    If($xsize -eq $null){$xsize = 100} If($ysize -eq $null){$ysize = 50} # - Makes sure a default size is set
    $bname = New-Object $Button ; $bname.Size = New-Object $Size($xsize,$ysize) ; $bname.Location = New-Object $Location($xpos,$ypos) # - Creates the button and size/location
    $bname.Text = $text # - Sets the button Text
    $bname
}

Function Add-ListBox($name,$xsize,$ysize,$xpos,$ypos) {
    New-Variable -Name $name -Value $lname # - Creates the variable
    $lname = New-Object $ListBox ; $lname.Size = New-Object $Size($xsize,$ysize) ; $lname.Location = New-Object $Location($xpos,$ypos) # - Creates the listbox and size/location
    $lname.Font = $Font_Primary # - Sets the listbox font
    $lname
}

Function Add-Background($name,$xsize,$ysize,$xpos,$ypos,$color) {
    New-Variable -Name $name -Value $bkgname # - Creates the variable
    $bkgname = New-Object $PictureBox ; $bkgname.Size = New-Object $Size($xsize,$ysize) ; $bkgname.Location = New-Object $Location($xpos,$ypos) # - Creates the background and size/location
    $bkgname.BackColor = $color ; $bkgname.BorderStyle = 'Fixed3D' # - Sets the background color and border style
    $bkgname
}
#endregion

#region <# Script Functions #>
Function Check-Drives {
    param([string]$Comp)
    $Script:Svr = $Comp # - Creates script wide varaible
    If($Script:CurrentBars.Count -gt 0){ ForEach($Bar in $Script:CurrentBars){$MainForm.Controls.Remove($Bar)}} # - Resets barcount
    $lbl_ConnectStatus.Text = "Testing..." ; $lbl_ConnectStatus.ForeColor = 'Black' ; $lbl_TotalVolumes.Text = "" # - Resets labels for test-connection
    If(!(Test-Connection $Comp -Count 2 -buffer 16 -Quiet -ErrorAction Si)){ $lbl_ConnectStatus.Text = "OFFLINE" ; $lbl_ConnectStatus.ForeColor = 'Red'} # - Test-Connection + Failure
    Else{ $lbl_ConnectStatus.Text = "ONLINE" ; $lbl_ConnectStatus.ForeColor = 'Green' ; $lbl_TotalVolumes.Text = "Loading..." # - Test-Connection + Success
          $Script:Drives = Get-WmiObject -Class win32_Volume -ComputerName $Comp | Select * | Where Capacity -GT 0 ; $lbl_TotalVolumes.Text = $Script:Drives.Count # - Loads Drive count
          
        <# Gather Page Count #>
        [int]$Total = 0
        [int]$num = 0
        [int]$pages = 1
        Do{$total++ ; $num++ ; If($num -eq 12){$pages++ ; $num = 0}} Until($Total -eq $Drives.Count) ; $Script:PageCount = $pages
        If($Script:PageCount -lt 1){$Script:PageCount = 1} ; $Script:CurrentPage = 1
        If($Script:PageCount -eq 1){$btn_Next.Enabled = $false} Else{$btn_Next.Enabled = $true}
        $lbl_pages.Text = "Page " + $Script:CurrentPage + " of " + $Script:PageCount
    }
}

Function Get-Page {
    param([string]$Page)
    If($Script:CurrentBars.Count -gt 0){ForEach($Bar in $Script:CurrentBars){$MainForm.Controls.Remove($Bar)}} # - Resets progress bars
    If($Page -eq 1){$Range = 0..11 ; $Script:CurrentPage = 1}
    If($Page -eq 2){$Range = 12..23 ; $Script:CurrentPage = 2}
    If($Page -eq 3){$Range = 24..35 ; $Script:CurrentPage = 3}
    If($Page -eq 4){$Range = 36..47 ; $Script:CurrentPage = 4}
    If($Page -eq 5){$Range = 48..59 ; $Script:CurrentPage = 5}
    If($Page -eq 6){$Range = 60..71 ; $Script:CurrentPage = 6}
    If($Page -eq 7){$Range = 72..83 ; $Script:CurrentPage = 7}
    If($Page -eq 8){$Range = 84..95 ; $Script:CurrentPage = 8}
    If($Page -eq 9){$Range = 96..107 ; $Script:CurrentPage = 9}
    If($Page -eq 10){$Range = 108..119 ; $Script:CurrentPage = 10} 

    $Number = 0 ; $Count = 0 ; $xpos = 20 ; $ypos = 10 # - Setting Variables
    $btn_MoreInfo.Enabled = $true ; $btn_ExportOptions.Enabled = $true # - Enabling Buttons
    If($lbl_ConnectStatus.Text -eq "OFFLINE"){$Script:Drives.Clear() ; $btn_ExportOptions.Enabled = $false ; $btn_MoreInfo.Enabled = $false} Else{
    ForEach($Disk in $Script:Drives[$Range]){ $Count++ ; If($Count -gt 12){} Else{
        If($Count -lt 5){$ypos = 160} ElseIf($Count -gt 4 -and ($Count -lt 9)){$ypos = 260} ElseIf($Count -gt 8 -and ($Count -lt 13)){$ypos = 360} # - Sets up label variables
        If($Count -eq  5 -or ($Count -eq 9 -or ($Count -eq 13))){$xpos = 20} # - Sets up the columns
        $varname = 'bar_' + $Count + '_' + $Disk.Label # - Sets the progress bar variable name
        $labname = 'label_' + $Count + '_' + $Disk.Label # - Sets the progress bar label name
        If(Get-Variable -Name $varname -ErrorAction Si){Remove-Variable -Name $varname} # - Resets progress bar variables

        $Free = [math]::Round(([long]$Disk.FreeSpace / 1GB),2)
        $Total = [math]::Round(([long]$Disk.Capacity / 1GB),2)
        [int]$UsedSpace = $Total - $Free
        [int]$Percent = $UsedSpace / $Total * 100
        [string]$Data = $Disk.DriveLetter + $Disk.Label + "`n" + "[" + $UsedSpace + "GB / " + $Total + "GB]" + "     " + $Percent + "%"
        $CreateLabel = Add-Label $labname 200 30 $xpos $ypos $Data ; $Script:CurrentBars.Add($CreateLabel) ; $MainForm.Controls.Add($CreateLabel) # - Creates the Data Label

        If($Count -lt 5){$ypos = 190} ElseIf($Count -gt 4 -and ($Count -lt 9)){$ypos = 290} ElseIf($Count -gt 8 -and ($Count -lt 13)){$ypos = 390} # - Sets up bar variables
        $CreateBar = Add-Bar $varname $xpos $ypos $Percent ; $Script:CurrentBars.Add($CreateBar) ; $MainForm.Controls.Add($CreateBar) # - Creates the Progress bar

        $xpos = $xpos + 210 # - Moving xpos to next location
        $bkg_Drives.SendToBack() # - Makes sure background stays in the back
        }
    }}
}

Function Change-Page {
    Param([switch]$Next, [switch]$Previous)
    If($Next){
        If($Script:CurrentPage -lt $Script:PageCount){$Script:CurrentPage++ ; Get-Page -Page $Script:CurrentPage}
        $lbl_Pages.Text = "Page " + $Script:CurrentPage + " of " + $Script:PageCount
        }
    If($Previous){
        If($Script:CurrentPage -gt 1){$Script:CurrentPage-- ; Get-Page -Page $Script:CurrentPage}
        $lbl_Pages.Text = "Page " + $Script:CurrentPage + " of " + $Script:PageCount
        }
    If($Script:CurrentPage -lt $Script:PageCount){$btn_Next.Enabled = $true} Else{$btn_Next.Enabled = $false}
    If($Script:CurrentPage -eq 1){$btn_Previous.Enabled = $False} Else{$btn_Previous.Enabled = $true}
}

Function Load-PBAs {
    $Script:List_PBAs = Get-Content -Path $Folder_PBAs
    ForEach($PBA in $Script:List_PBAs){$PBA_List.Items.Add($PBA)}
}

Function Load-Servers {
    $Servers_List.Enabled = $true ; $Servers_List.Items.Clear()
    $Selected_PBA = $PBA_List.SelectedItem.ToString()
    [string]$Chosen_PBA = 'N' + $Selected_PBA.Remove(3)
    $Servers = Get-ADComputer -Filter {(OperatingSystem -like "Windows Server*")} | Where Name -like "$Chosen_PBA*" | Select -Expand Name | Sort-Object
    If($Servers -eq $null){$Servers_List.Items.Add("No Servers Available") ; $Servers_List.Enabled = $false ; $btn_MoreInfo.Enabled = $false} Else{ForEach($Svr in $Servers){$Servers_List.Items.Add($Svr)}}
}

Function Get-VolumeInfo {
    $SelectedVolume = $VolumeList.SelectedIndex
    $VolumeName = $Script:Drives[$SelectedVolume].Label
    $VolumePath = $Script:Drives[$SelectedVolume].Path
    $VolumeDrive = $Script:Drives[$SelectedVolume].DriveLetter
    $VolumeFileSystem = $Script:Drives[$SelectedVolume].FileSystem

    $lbl_info_label2.Text = $VolumeName ; $lbl_info_Path2.Text = $VolumePath ; $lbl_info_Drive2.Text = $VolumeDrive ; $lbl_info_filesystem2.Text = $VolumeFileSystem # - Sets the Label Text to the Data
}

Function Load-Volumes {
    $VolumeList.Items.Clear() ; $VolumeList.Text = "" ; ForEach($Drive in $Script:Drives){$VolumeList.Items.Add($Drive.Label)}
}

Function Export-Volumes {
    Param([switch]$CSV, [switch]$Worksheet)

    <# Gather Variables #>
    [string]$Svr = $Script:Servers_List.SelectedItem.ToString()
    $Date = Get-Date -UFormat "%d-%B-%Y-%r" ; $Date = $Date.Replace(":","") ; $Date = $Date.Replace(" ","")
    $FileName = $Svr + "_" + $Date
    $Script:ExportData.Clear()
        
    $Script:lbl_export_status.Text = "Exporting..." ; $Script:lbl_export_status.ForeColor = 'Yellow' # - Update Status Label

    If($CSV){
        ForEach($Disk in $Script:Drives){
            $Free = [math]::Round(([long]$Disk.FreeSpace / 1GB),2)
            $Total = [math]::Round(([long]$Disk.Capacity / 1GB),2)
            [int]$UsedSpace = $Total - $Free
            [int]$Percent = $UsedSpace / $Total * 100
            $Script:ExportData += [pscustomobject] @{
                Label = $Disk.Label
                FileSystem = $Disk.FileSystem
                Capacity_GB = $Total
                FreeSpace_GB = $Free
                PercentUsed = $Percent.ToString() + "%"
                }
            }
        
        $Script:ExportData | Select Label,FileSystem,Capacity_GB,FreeSpace_GB,PercentUsed | Export-Csv -Path $Folder_Results\$FileName.csv -NoTypeInformation -Encoding UTF8 # - Exports to CSV
        $Script:lbl_export_status.Text = "Exported!" ; $Script:lbl_export_status.ForeColor = 'Green' # - Updates Label
        $Open = Invoke-Item $Folder_Results\$FileName.csv # - Opens the file
    }

    If($Worksheet){
        <# Creation of Excel Sheet #>
        $Excel = New-Object -ComObject excel.application ; $Workbook = $Excel.Workbooks.Add() # - Creates the ComObject and Workbook
        $ServerInfoSheet = $Workbook.Worksheets.Item(1) ; $ServerInfoSheet.Name = 'DiskInformation' # - Names the Worksheet
        $ServerInfoSheet.Visible = $true ; $ServerInfoSheet.Activate() | Out-Null

        <# Creating the Rows / Columns #>
        $row = 1 ; $column = 1 # - Assigns the columns
        $ServerInfoSheet.Cells.Item($row,$column) = 'Disk Space Information' # - Creates the Title
            $ServerInfoSheet.Cells.Item($row,$column).Font.Size = 18 ; $ServerInfoSheet.Cells.Item($row,$column).Font.Bold = $true
            $ServerInfoSheet.Cells.Item($row,$column).Font.Name = 'Cambria' ; $ServerInfoSheet.Cells.Item($row,$column).Font.ThemeFont = 1
            $ServerInfoSheet.Cells.Item($row,$column).Font.ThemeColor = 4 ; $ServerInfoSheet.Cells.Item($row,$column).Font.ColorIndex = 55
            $ServerInfoSheet.Cells.Item($row,$column).Font.Color = 8210719 # - Formats the Title,Size,Colors
        $SheetRange = $ServerInfoSheet.Range("a1","e2") ; $SheetRange.Style = 'Title' # - Setting the Title Range
        $SheetRange.Merge() | Out-Null ; $SheetRange.VerticalAlignment = -4108 # - Aligning the Title Text
        $row++ ; $row++ # - Set Row to 3
        $InitialRow = $row ; $InitialColumn = $column # - Setting the Initial Rows/Columns

        <# Creation of Headers #>
        $ServerInfoSheet.Cells.Item($row,$column) = 'Disk Label' # - Disk Label Column
        $ServerInfoSheet.Cells.Item($row,$column).Interior.ColorIndex = 48 ; $ServerInfoSheet.Cells.Item($row,$column).Font.Bold = $true ; $column++ 
        $ServerInfoSheet.Cells.Item($row,$column) = 'File System' # - File System Column
        $ServerInfoSheet.Cells.Item($row,$column).Interior.ColorIndex = 48 ; $ServerInfoSheet.Cells.Item($row,$column).Font.Bold = $true ; $column++
        $ServerInfoSheet.Cells.Item($row,$column) = 'Capacity (GB)' # - Drive Capacity Column
        $ServerInfoSheet.Cells.Item($row,$column).Interior.ColorIndex = 48 ; $ServerInfoSheet.Cells.Item($row,$column).Font.Bold = $true ; $column++
        $ServerInfoSheet.Cells.Item($row,$column) = 'Free Space (GB)' # - Drive Free Space Column
        $ServerInfoSheet.Cells.Item($row,$column).Interior.ColorIndex = 48 ; $ServerInfoSheet.Cells.Item($row,$column).Font.Bold = $true ; $column++
        $ServerInfoSheet.Cells.Item($row,$column) = 'Percentage Used' # - Drive Percent Used Column
        $ServerInfoSheet.Cells.Item($row,$column).Interior.ColorIndex = 48 ; $ServerInfoSheet.Cells.Item($row,$column).Font.Bold = $true ; $column++

        <# Adding the Worksheet Information #>
        $row++ ; $column = 1
        ForEach($Disk in $Script:Drives){
            $Free = [math]::Round(([long]$Disk.FreeSpace / 1GB),2)
            $Total = [math]::Round(([long]$Disk.Capacity / 1GB),2)
            [int]$UsedSpace = $Total - $Free
            [int]$Percent = $UsedSpace / $Total * 100
            
            $ServerInfoSheet.Cells.Item($row,$column) = $Disk.Label ; $column++ # - Label Name
            $ServerInfoSheet.Cells.Item($row,$column) = $Disk.FileSystem ; $column++ # - File System
            $ServerInfoSheet.Cells.Item($row,$column) = $Total ; $column++ ; # - Capacity (GB)
            $ServerInfoSheet.Cells.Item($row,$column) = $Free ; $column ++ ; # - Free Space (GB)
            $ServerInfoSheet.Cells.Item($row,$column) = $Percent.ToString() + "%" ; $column++ # - Percentage Used (GB)
            
            $SheetRange = $ServerInfoSheet.Range(("A{0}" -f $row), ("E{0}" -f $Row)) ; $SheetRange.Select() | Out-Null # - Selects the Percentage Used Range
            If($Percent -lt 90 -and ($Percent -gt 69)){$SheetRange.Interior.ColorIndex = 6} # - Yellow Coloring
            ElseIf($Percent -ge 90){$SheetRange.Interior.ColorIndex = 3} # - Red Coloring
            $column = 1 ; $row++
            }
        
        <# Worksheet Customization #>
        $row-- ; $DataRange = $ServerInfoSheet.Range(("A{0}" -f $InitialRow), ("E{0}" -f $row))
        7..12 | ForEach{$DataRange.Borders.Item($_).LineStyle = 1 ; $DataRange.Borders.Item($_).Weight = 2} # - Creates the Borders of the sheet
        $UsedRange = $ServerInfoSheet.UsedRange() ; $UsedRange.EntireColumn.Autofit() | Out-Null # - Autosize the cells to fit the text

        <# Saving the Workbook and Closing Excel #>
        $Workbook.SaveAs("$Folder_Results\$FileName.xlsx") ; $Excel.Quit()

        <# Process Finish #>
        $Script:lbl_export_status.Text = "Exported!" ; $Script:lbl_export_status.ForeColor = 'Green' # - Updates the Status Label
        $Open = Invoke-Item -Path $Folder_Results\$FileName.xlsx
    }    
}

Function Get-DetailedInfo {
    <# Primary Form #>
    $Script:Form_Info = New-Object $Form ; $Form_Info.Size = New-Object $Size(300,400) ; $Form_Info.FormBorderStyle = 'Fixed3D' ; $Form_Info.ControlBox = $false # - Creates the Detailed Info Form
    $Form_Info.Text = "Detailed Volume Info"

    <# Volume Combo Box #>
    $Script:VolumeList = New-Object $ComboBox ; $VolumeList.Size = New-Object $Size(260,100) ; $VolumeList.Location = New-Object $Location(15,5) ; $Form_Info.Controls.Add($VolumeList) # - Creates the Combo Box
    $VolumeList.Font = $Font_Secondary ; $VolumeList.Add_SelectedIndexChanged({Get-VolumeInfo})

    <# Label For Volume Name #>
    $Script:lbl_info_label1 = Add-Label lbl_info_label1 250 30 20 40 "Label " ; $Form_Info.Controls.Add($lbl_info_label1) # - Creates the Label for disk label
    $Script:lbl_info_label2 = Add-Label lbl_info_label2 190 20 70 45 "" ; $Form_Info.Controls.Add($lbl_info_label2) # - Creates the label to be modified
    $lbl_info_label1.BackColor = 'LightGray' ; $lbl_info_label1.TextAlign = 'MiddleLeft'
    $lbl_info_label2.BackColor = 'LightGray' ; $lbl_info_label2.BringToFront()

    <# Label For Path Location #>
    $Script:lbl_info_path1 = Add-Label lbl_info_path1 250 30 20 80 "Path " ; $Form_Info.Controls.Add($lbl_info_path1) # - Creates the label for path label
    $Script:lbl_info_path2 = Add-Label lbl_info_path2 190 20 70 85 "" ; $Form_Info.Controls.Add($lbl_info_path2) # - Creates the label to be modified
    $lbl_info_path1.BackColor = 'LightGray' ; $lbl_info_path1.TextAlign = 'MiddleLeft'
    $lbl_info_path2.BackColor = 'LightGray' ; $lbl_info_path2.BringToFront()

    <# Label For Drive Name #>
    $Script:lbl_info_drive1 = Add-Label lbl_info_drive1 250 30 20 160 "Drive " ; $Form_Info.Controls.Add($lbl_info_drive1) # - Creates the label for the drive label
    $Script:lbl_info_drive2 = Add-Label lbl_info_drive2 190 20 70 165 "" ; $Form_Info.Controls.Add($lbl_info_drive2) # - Creates the label to be modified
    $lbl_info_drive1.BackColor = 'LightGray' ; $lbl_info_drive1.TextAlign = 'MiddleLeft'
    $lbl_info_drive2.BackColor = 'LightGray' ; $lbl_info_drive2.BringToFront()

    <# Label For FileSystem #>
    $Script:lbl_info_filesystem1 = Add-Label lbl_info_filesystem1 250 30 20 120 "FileSystem" ; $Form_Info.Controls.Add($lbl_info_filesystem1) # - Creates the label for the FileSystem Label
    $Script:lbl_info_filesystem2 = Add-Label lbl_info_filesystem2 150 20 110 125 "" ; $Form_Info.Controls.Add($lbl_info_filesystem2) # - Creates the label to be modified
    $lbl_info_filesystem1.BackColor = 'LightGray' ; $lbl_info_filesystem1.TextAlign = 'MiddleLeft'
    $lbl_info_filesystem2.BackColor = 'LightGray' ; $lbl_info_filesystem2.BringToFront()

    <# Exit Button #>
    $Script:btn_info_exit = Add-Button btn_info_exit 110 40 160 315 "Close" ; $Form_Info.Controls.Add($btn_info_exit) # - Creates the Exit Button
    $btn_info_exit.Add_Click({$btn_MoreInfo.Enabled = $true ; $Form_Info.Dispose()})

    <# Refresh Volumes Button #>
    $Script:btn_info_refresh = Add-Button btn_info_refresh 110 40 20 315 "Refresh" ; $Form_Info.Controls.Add($btn_info_refresh) # - Creates the Refresh Button
    $btn_info_refresh.Add_Click({Load-Volumes})

    <# Background #>
    $bkg_info = Add-Background bkg_info 260 280 15 30 'Gray' ; $Form_Info.Controls.Add($bkg_info) # - Creates the Background
    $bkg_info.SendToBack()

    <# Process on Load #>
    $Load = Load-Volumes ; $btn_MoreInfo.Enabled = $false
    $Form_info.Show()
}

Function Get-ExportOptions {
    <# Primary Form #>
    $Script:Form_Export = New-Object $Form ; $Form_Export.Size = New-Object $Size(160,290) ; $Form_Export.FormBorderStyle = 'Fixed3D' # - Creates the Primary Form
    $Form_Export.ControlBox = $false ; $Form_Export.Text = "Export Options"

    <# Exit Button #>
    $Script:btn_export_exit = Add-Button btn_export_exit 100 40 20 200 "Close" ; $Form_Export.Controls.Add($btn_export_exit) # - Creates the Exit button
    $btn_export_exit.Add_Click({$Form_Export.Dispose() ; $btn_ExportOptions.Enabled = $true})

    <# Results Folder Button #>
    $Script:btn_export_resultsfolder = Add-Button btn_export_resultsfolder 100 40 20 150 "Exports Folder" ; $Form_Export.Controls.Add($btn_export_resultsfolder) # - Creates the Results Folder Button
    $btn_export_resultsfolder.Add_Click({Invoke-Item -Path $Folder_Results})

    <# Export as Worksheet Button #>
    $Script:btn_export_exportworksheet = Add-Button btn_export_exportworksheet 100 40 20 100 "Export as Worksheet" ; $Form_Export.Controls.Add($btn_export_exportworksheet) # - Creates the Export(Worksheet) Button
    $btn_export_exportworksheet.Add_Click({Export-Volumes -Worksheet})

    <# Export as CSV Button #>
    $Script:btn_export_exportcsv = Add-Button btn_export_exportcsv 100 40 20 50 "Export as CSV" ; $Form_Export.Controls.Add($btn_export_exportcsv) # - Creates the Export(CSV) Button
    $btn_export_exportcsv.Add_Click({Export-Volumes -CSV})

    <# Export Status Label #>
    $Script:lbl_export_status = Add-Button lbl_export_status 125 20 7 15 "Make a Selection" ; $Form_Export.Controls.Add($lbl_export_status) # - Creates the Export Status Label
    $lbl_export_status.ForeColor = 'Cyan' ; $lbl_export_status.BackColor = 'Black'

    <# Background #>
    $bkg_export = Add-Background bkg_export 130 190 5 5 'LightGray' ; $Form_Export.Controls.Add($bkg_export) # - Creates the Export Background

    <# Process Load #>
    $Form_Export.Show() ; $btn_ExportOptions.Enabled = $false
}
#endregion

#region <# Form Construction #>
<# Main Form #>
$MainForm = New-Object $Form ; $MainForm.Size = New-Object $Size(885,500) ; $MainForm.FormBorderStyle = 'Fixed3D' # - Creates the Main Form

<# Next Page Button #>
$btn_Next = Add-Button btn_Next 100 30 755 75 "Next Page" ; $MainForm.Controls.Add($btn_Next)
$btn_Next.Add_Click({Change-Page -Next}) ; $btn_Next.Enabled = $false ; $btn_Next.BackColor = 'Cyan'

<# Previous Page Button #>
$btn_Previous = Add-Button btn_Previous 100 30 755 110 "Previous Page" ; $MainForm.Controls.Add($btn_Previous)
$btn_Previous.Add_Click({Change-Page -Previous}) ; $btn_Previous.Enabled = $false ; $btn_Previous.BackColor = 'Cyan'

<# Volume Information Button #>
$btn_MoreInfo = Add-Button btn_MoreInfo 110 50 500 85 "Detailed Volume Info" ; $MainForm.Controls.Add($btn_MoreInfo)
$btn_MoreInfo.Add_Click({Get-DetailedInfo}) ; $btn_MoreInfo.Enabled = $false ; $btn_MoreInfo.BackColor = 'DarkGreen' ; $btn_MoreInfo.Font = $Font_Secondary

<# Export Options Button #>
$btn_ExportOptions = Add-Button btn_ExportOptions 110 50 625 85 "Export Options" ; $MainForm.Controls.Add($btn_ExportOptions)
$btn_ExportOptions.Add_Click({Get-ExportOptions}) ; $btn_ExportOptions.BackColor = 'Orange' ; $btn_ExportOptions.Font = $Font_Secondary

<# Exit Button #>
$btn_Exit = Add-Button btn_Exit 100 40 755 10 "EXIT" ; $MainForm.Controls.Add($btn_Exit)
$btn_Exit.Add_Click({$MainForm.Dispose()}) ; $btn_Exit.BackColor = 'Red'

<# Current Page Lebel #>
$lbl_Pages = Add-Label lbl_Pages 100 20 755 55 "Page 0 of 0" x ; $MainForm.Controls.Add($lbl_Pages)
$lbl_Pages.ForeColor = 'Yellow'

<# PBA and Server List Labels #>
$lbl_PBAList = Add-Label lbl_PBAList 270 30 10 5 "PBA / SITE LIST" ; $MainForm.Controls.Add($lbl_PBAList)
$lbl_ServerList = Add-Label lbl_ServerList 200 30 285 5 "SERVER LIST" ; $MainForm.Controls.Add($lbl_ServerList)

<# Server Information Label #>
$lbl_SvrInfo = Add-Label lbl_SvrInfo 255 20 490 5 "Server Information" ; $MainForm.Controls.Add($lbl_SvrInfo)

<# Connection Test Label #>
$lbl_ConnectionTest = Add-Label lbl_ConnectionTest 110 20 495 30 "Server Status : " x ; $MainForm.Controls.Add($lbl_ConnectionTest)
$lbl_ConnectionTest.BackColor = 'LightGray' ; $lbl_ConnectionTest.TextAlign = 'TopLeft'

<# Connection Status Label #>
$lbl_ConnectStatus = Add-Label lbl_ConnectStatus 100 20 610 30 "" x ; $MainForm.Controls.Add($lbl_ConnectStatus)
$lbl_ConnectStatus.BackColor = 'LightGray' ; $lbl_ConnectStatus.TextAlign = 'TopLeft' ; $lbl_ConnectStatus.ForeColor = 'Green'

<# Volume Count Label #>
$lbl_VolumeCount = Add-Label lbl_VolumeCount 110 20 495 60 "Volume Count : " x ; $MainForm.Controls.Add($lbl_VolumeCount)
$lbl_VolumeCount.BackColor = 'LightGray' ; $lbl_VolumeCount.TextAlign = 'TopLeft'

<# Total Volume Count Label #>
$lbl_TotalVolumes = Add-Label lbl_TotalVolumes 100 20 610 60 "" ; $MainForm.Controls.Add($lbl_TotalVolumes)
$lbl_TotalVolumes.BackColor = 'LightGray' ; $lbl_TotalVolumes.TextAlign = 'TopLeft'

<# PBA / Sites ListBox #>
$PBA_List = Add-ListBox PBA_List 270 115 10 35 ; $MainForm.Controls.Add($PBA_List)
$PBA_List.Add_SelectedIndexChanged({Load-Servers})

<# Servers ListBox #>
$Servers_List = Add-ListBox Servers_List 200 115 285 35 ; $MainForm.Controls.Add($Servers_List)
$Servers_List.Add_SelectedIndexChanged({Check-Drives -Comp $Servers_List.SelectedItem.ToString() ; Get-Page -Page 1})

<# Backgrounds #>
$bkg_Drives = Add-Background bkg_Drives 850 300 10 150 'LightGray' ; $MainForm.Controls.Add($bkg_Drives)
$bkg_Pages = Add-Background bkg_Pages 110 90 750 55 'Gray' ; $MainForm.Controls.Add($bkg_Pages)
$bkg_Stats = Add-Background bkg_Stats 255 120 490 25 'LightGray' ; $MainForm.Controls.Add($bkg_Stats)
#endregion

<# Process upon start of script #>
$Load = Load-PBAs
[System.Windows.Forms.Application]::Run($MainForm)