﻿

<#
 .Synopsis
  Retrieve all HDD Space information for every DC on the domain 

 .Description
  Allows the Administrator to easily access Hard Disk Drive information of all DC's connected on the domain

 .Example
    Get-DomainControllerSpace
    # Runs the Script normally.

 .Example
    Get-DomainControllerSpace -OpenReport
    # Opens the created report file after completion.
   
#>

[cmdletbinding()]
param([Parameter (Mandatory = $false)][switch]$OpenReport)
#######################################################################
# Created by Daniel Rosborough
# Last updated: 21 Sep 2021
#
# This script is used to monitor hard drive space on Domain Controllers
# Red indicates a drive that is below 10% free space.
# Yellow indicates drives that are between 10 and 20% free space.
# Green, as always is good.
#
# Script should be run once a month or anytime Domain Contoller problems occur.
# Prerequisite: RSAT or Server tools required on your workstation.



$folder = "\\newton\admin\Scripts\Monthly Scripts\HardDriveSpace\Reports-DCs"
######################################################################


$LogTime = Get-Date -Format "yyyyMMddhhmmss"
$ReportDate = Get-Date

$logfile = "$folder\DCDriveSpace-$LogTime.txt" 
 
$Computers = ""

$Computers = Get-ADComputer -filter 'Name -like "*DC0*" -and Name -notlike "*XDC0*" -and OperatingSystem -like "Windows Server*"' | Sort-Object Name | Select-Object Name

$cnt = 1
"Server 	         Drive         	         Size  	 Free  	  Free%" | Out-File $logfile -Append
foreach ($Comp in $Computers) {
    $Computer = ""
    $Computer = $Comp.Name
     
    Write-Host "Processing $Computer              Size  	 Free  	  Free%"
    $Test = Test-Connection $Computer -ErrorAction SilentlyContinue -Count 1
      if ($Test) {
    $Drives = Get-WmiObject Win32_Volume -ComputerName $Computer | select SystemName, DriveLetter, Label, Capacity, FreeSpace 
   
    foreach ($Drive in $Drives ) {
       
        $ComputerName = $Drives.SystemName
        $Letter = $Drive.DriveLetter
        $Name = $Drive.Label
        $Size = [math]::Round(([long]$Drive.Capacity / 1GB ),2)
        $FreeSpace =  [math]::Round(([long]$Drive.FreeSpace / 1GB ),2)
        if ($FreeSpace -gt 0 ) {
            $FreePercent = 100 * ( [math]::Round($FreeSpace / $Size,2)) }
        else {
            $FreePercent = 0
        }
        if ($FreePercent -gt 20)  {
            $ShowAlert = '<td>' }
        Else {
            
            if ($FreePercent -lt 10) {
                $ShowAlert = '<td class="alert-red">'}
            Else {
               $ShowAlert = '<td class="alert-yellow">'}
         }
         

        Switch ($Letter) {
            'A:'{ } 
            'Z:'{ }         
         default {
            If ($Drive.Capacity -gt 0) {
                If($Letter.Length -gt 0){
                    $Name = "$Letter $Name"
                }
                $Name = $Name.PadRight(17, " ")
                $Code = ""
                
                if ($FreePercent -gt 20) {
                    Write-Host "  $Computer`t $Name`t $Size`t $FreeSpace`t  $FreePercent" -ForegroundColor Green}
                elseif ($FreePercent -lt 11) {
                    Write-Host "  $Computer`t $Name`t $Size`t $FreeSpace`t  $FreePercent" -ForegroundColor Red
                    $Code = "Critical"}
                else {
                    Write-Host "  $Computer`t $Name`t $Size`t $FreeSpace`t  $FreePercent" -ForegroundColor Yellow 
                     $Code = "Low"}      
                "$Computer`t $Name`t $Size`t $FreeSpace`t  $FreePercent `t $Code" | Out-file $logfile -Append
          }
        }
        }
       }
    }
    Write-Host " "
    
}
Write-Host "Done."

If($OpenReport){Invoke-Item $logfile}

