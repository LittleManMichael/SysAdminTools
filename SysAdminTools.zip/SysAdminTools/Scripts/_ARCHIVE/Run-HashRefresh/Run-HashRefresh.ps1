﻿
<#
 .Synopsis
  Refresh the password hash for all AD Accounts requiring smartcard logon.

 .Description
  Refresh the password hash for all AD Accounts requiring smartcard logon.

 .Example
    Run-HashRefresh
    # Runs the Script as intended.
#>

### UPDATE - 11/12/2023 ###
# Adding in the unlocking of all AD Accounts that were refreshed #
########################### 

$Users = Get-ADUser -Filter {(SmartcardLogonRequired -eq $True)} -Properties SmartcardLogonRequired
[int]$total = $Users.Count * 2
[int]$cnt = 0

ForEach($i in $Users){
    $Name = $i.Name
    $sam = $i.SamAccountName
    
    $off = Set-ADUser -Identity $sam -SmartcardLogonRequired $false -ErrorAction si 
    $on = Set-ADUser -Identity $sam -SmartcardLogonRequired $true -ErrorAction si 

    $cnt++
    [int]$Percent = $cnt / $total * 100
    Write-Progress -Activity "Refreshing Account Hash" -Status "$Percent%" -CurrentOperation $Name -PercentComplete $Percent
}

Write-Progress -Activity "Refreshing Account Hash" -Status "$Percent%" -CurrentOperation "WAITING FOR REPLICATION TO UNLOCK ACCOUNTS" -PercentComplete $Percent
Start-Sleep -Seconds 300

ForEach($x in $Users){
    $Name = $x.Name
    $acc = $x.SamAccountName

    $unlock = Unlock-ADAccount $acc
    $cnt++
    [int]$Percent = $cnt / $total * 100
    Write-Progress -Activity "Refreshing Account Hash" -Status "$Percent%" -CurrentOperation "Unlocking $Name" -PercentComplete $Percent
}

$logpath = "\\newton\admin\SysAdmin Powershell Module\Scripts\BattleRythm\Logs\Log_BattleRhythm.csv"
Add-Content -Path $logpath -Value "`Run-HashRefresh,$(get-date -Format 'MM/d/yyyy hh:mm:ss'),$(whoami)"
