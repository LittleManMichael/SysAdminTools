﻿
$Date = Get-Date -Format dd-mm-yyyy
$Time = Get-Date -Format hhmm

Write-Host "Connecting to the VCSA Servers..." -f Yellow -b Black -NoNewline

# Connect to the VCSA Servers
$VCSA490 = Connect-VIServer -Server N490VCSA01
$VCSA066 = Connect-VIServer -Server N066VCSA02

Write-Host "Done." -f Green -b Black ; Write-Host "" ; Write-Host ""

# Gather the list of RHEL Servers
$RHELServers = Get-Content -Path "\\newton\admin\SysAdmin Powershell Module\Scripts\Create-RHELSnapshots\RHEL Servers.txt"

# Go through each RHEL Server
ForEach($Svr in $RHELServers){
    
    # Begin output for each server
    Write-Host "Server Name : " -f White -b Black -no ; Write-Host "$Svr" -f Yellow -b Black

    # Check Snapshot count
    $Snapshots = Get-Snapshot -vm $Svr
    Write-Host "Snapshot Count : " -f White -no ; Write-Host $Snapshots.count -f Yellow

    # Chek snapshot count. If greater than 1, remove old ones. Else, move on to creating new snapshot
    If($Snapshots.count -gt 1){
        
        Write-Host "Removing Old Snapshots..." -f Gray -NoNewline

        # Go through each snapshot
        ForEach($Snapshot in $Snapshots){
            
            # Remove the old snapshots UP TO the current one
            If($Snapshot.IsCurrent -eq $false){ Get-Snapshot -vm $Svr $Snapshot | Remove-Snapshot }
            Start-Sleep -Seconds 5
        }
    
    Write-Host "Done." -f Green
    
    }

    Write-Host "Creating New Snapshot..." -f Gray -NoNewline

    # Create new snapshot
    $CreateSnapshot = New-Snapshot -VM $Svr -Name "REMOTE-SNAPSHOT on $Date at $Time" -Description "Snapshot created remotely via powershell by $env:USERNAME" -Memory
    Start-Sleep -Seconds 5
    Write-Host "Done." -f Green ; Write-Host ""
}
