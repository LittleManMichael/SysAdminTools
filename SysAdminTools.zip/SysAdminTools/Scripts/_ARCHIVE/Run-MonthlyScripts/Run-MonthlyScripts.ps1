

<#
 .Synopsis
  Automates any type of monthly script. Includes last ran date. 

 .Description
  Allows admins to quickly run monthly scripts

 .Example
   Run-MonthlyScrips
   # Loads the form
   

#>

[void][System.Reflection.Assembly]::LoadWithPartialName('System.Windows.Forms')
[void][System.Reflection.Assembly]::LoadWithPartialName('System.Drawing')

#region VARIABLES

## Primary Variables ##
$Network = 'DC=newton, DC=pentagon, DC=mil'
$TimeStamp = Get-Date -UFORMAT "%d %B %Y"
$FilePath_CSV = "\\newton\admin\SysAdmin Powershell Module\Scripts\Run-MonthlyScripts\Log_LastRan.csv"
$LastRan = Import-Csv $FilePath_CSV
$Break = ""
$log_staleusers_dateran = $LastRan[0].RunDate
$log_staleusers_ranby = $LastRan[0].ranby
$Disabled = [System.Collections.Generic.List[System.String]]@()



## Array Variables ##
#$CheckedItems = [System.Collections.Generic.List[System.String]] @()
#$Script:UserList = [System.Collections.Generic.List[System.String]] @()
#$MissingData = [System.Collections.Generic.List[System.String]] @()

## Font Configurations ##
$Font_Primary = [System.Drawing.Font]::new("Cosmic Sans", 12, [System.Drawing.FontStyle]::Bold)
$Font_Secondary = [System.Drawing.Font]::New("Cosmic Sans", 12)
$Font_MainForm = [System.Drawing.Font]::New("Cosmic Sans", 10)


## WinForm Shortcut Variables ##
$Location = 'System.Drawing.Point'
$Size = 'System.Drawing.Size'
$Form = 'System.Windows.Forms.Form'
$PictureBox = 'System.Windows.Forms.PictureBox'
$Button = 'System.Windows.Forms.Button'
$CheckBox = 'System.Windows.Forms.CheckBox'
$ComboBox = 'System.Windows.Forms.ComboBox'
$ListBox = 'System.Windows.Forms.ListBox'
$ListView = 'System.Windows.Forms.ListView'
$CheckedListBox = 'System.Windows.Forms.CheckedListBox'
$RadioButton = 'System.Windows.Forms.RadioButton'
$TextBox = 'System.Windows.Forms.TextBox'
$RichTextBox = 'System.Windows.Forms.RichTextBox'
$Label = 'System.Windows.Forms.Label'
$Timer = 'System.Windows.Forms.Timer'
$ProgressBar = 'System.Windows.Forms.ProgressBar'

#endregion


#region Commands for Button / Label Creation

Function Add-Button($Name,$xsize,$ysize,$xpos,$ypos,$text){
New-Variable -Name $Name -Value $bname
$bname = New-Object $Button
$bname.Size = New-Object $Size($xsize,$ysize)
$bname.Location = New-Object $Location($xpos,$ypos)
$bname.Text = $text
$bname
}

Function Add-Label($Name,$xsize,$ysize,$xpos,$ypos,$text,$color,$Fixed3D){
New-Variable -Name $Name -Value $lname
$lname = New-Object $Label
$lname.Size = New-Object $Size($xsize,$ysize)
$lname.Location = New-Object $Location($xpos,$ypos)
If($Fixed3D -eq $null){$lname.BorderStyle = 'FixedSingle'}
$lname.Font = $Font_MainForm
$lname.TextAlign = 'MiddleCenter'
$lname.BackColor = 'Gray'
$lname.ForeColor = $color
$lname.Text = $text
$lname
}

Function Add-Background($Name,$xsize,$ysize,$xpos,$ypos,$color){
New-Variable -Name $Name -Value $bkgname
$bkgname = New-Object $PictureBox
$bkgname.Size = New-Object $Size($xsize,$ysize)
$bkgname.Location = New-Object $Location($xpos,$ypos)
$bkgname.BackColor = $color
$bkgname.BorderStyle = 'Fixed3D'
$bkgname.SendToBack()
$bkgname
}
#endregion


Function Edit-Date { 
Param([string]$ScriptName)
$UpdateLog = [pscustomobject] @{
logname = $ScriptName
rundate = $TimeStamp
ranby = $env:USERNAME}

# Update the CSV File
$UpdateLog | Select logname,rundate,ranby | Export-csv -Path $FilePath_CSV -NoTypeInformation -Encoding UTF8 -Force
$LastRan = Import-Csv $FilePath_CSV

# Update the Stale users Ran date
$log_staleusers_dateran = $LastRan[0].RunDate ;
$lbl_StaleUsers_dateran.Text = $log_staleusers_dateran 

}

Function Job-StaleUsers {}

#region - Loading Main Menu Buttons
<# Main Form #>
$MainForm = New-Object $Form ; $MainForm.Size = New-Object $Size(820,700) # - Adds the Main Form
<# End Main Form #>

<# Stale Users #>
$btn_StaleUsers = Add-Button btn_staleusers 240 50 20 20 "Stale Users" ; $MainForm.Controls.Add($btn_StaleUsers) # - Adds the Button
$btn_StaleUsers.Font = $Font_Primary
$btn_StaleUsers.Add_Click({Job-StaleUsers})

$lbl_StaleUsers_dateran = Add-Label lbl_staleusers_dateran 240 30 20 80 "Last Ran : $log_staleusers_dateran" Yellow  ; $MainForm.Controls.Add($lbl_StaleUsers_dateran) # - Adds the Date Label
$lbl_StaleUsers_dateran.Font = $Font_Secondary

$lbl_StaleUsers_repeat = Add-Label lbl_staleusers_repeat 240 30 20 160 "Monthly Requirement" Yellow ; $MainForm.Controls.Add($lbl_StaleUsers_repeat) # - Adds the repeat Label
$lbl_StaleUsers_repeat.Font = $Font_Secondary

$bkg_StaleUsers = Add-Background bkg_staleusers 260 190 10 10 Gray ; $MainForm.Controls.Add($bkg_StaleUsers) # - Adds the Background
<# End Stale Users #>

<# Progress Hub #>

#$bar_Progress = New-Object $ProgressBar ; $bar_Progress.Size = New-Object $Size(300,50) ; $bar_Progress.Location = New-Object $Location(20,590) ; $MainForm.Controls.Add($bar_Progress)

$List_Disabled = New-Object $ListBox ; $List_Disabled.Size = New-Object $Size(300,140) ; $List_Disabled.Location = New-Object $Location(20,490) ; $MainForm.Controls.Add($List_Disabled)

#$bkg_ProgressHub = Add-Background bkg_progresshub 780 170 10 480 Gray ; $MainForm.Controls.Add($bkg_ProgressHub) # - Adds the Background
<# End Progress Hub #>
#endregion - End of Main Menu Buttons


















#LAST LINE HERE
[System.Windows.Forms.Application]::Run($MainForm)
#