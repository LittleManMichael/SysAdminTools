

<#
 .Synopsis
  Automates any type of monthly script. Includes last ran date. 

 .Description
  Allows admins to quickly run monthly scripts

 .Example
   Run-MonthlyScrips
   # Loads the form
   

#>

[void][System.Reflection.Assembly]::LoadWithPartialName('System.Windows.Forms')
[void][System.Reflection.Assembly]::LoadWithPartialName('System.Drawing')

#region VARIABLES

## Primary Variables ##
$Network = 'DC=newton, DC=pentagon, DC=mil'
$TimeStamp = Get-Date -UFORMAT "%d %B %Y"
$FilePath_CSV = "\\newton\admin\SysAdmin Powershell Module\Scripts\Run-MonthlyScripts\Log_LastRan.csv"
$LastRan = Import-Csv $FilePath_CSV
$Break = ""
$log_staleusers_dateran = $LastRan[0].RunDate
$log_staleusers_ranby = $LastRan[0].ranby
[int]$HideMainMenu = 1



## Array Variables ##
#$CheckedItems = [System.Collections.Generic.List[System.String]] @()
#$Script:UserList = [System.Collections.Generic.List[System.String]] @()
#$MissingData = [System.Collections.Generic.List[System.String]] @()

## Font Configurations ##
$Font_Primary = [System.Drawing.Font]::new("Cosmic Sans", 12, [System.Drawing.FontStyle]::Bold)
$Font_Secondary = [System.Drawing.Font]::New("Cosmic Sans", 12)
$Font_MainForm = [System.Drawing.Font]::New("Cosmic Sans", 10)


## WinForm Shortcut Variables ##
$Location = 'System.Drawing.Point'
$Size = 'System.Drawing.Size'
$Form = 'System.Windows.Forms.Form'
$PictureBox = 'System.Windows.Forms.PictureBox'
$Button = 'System.Windows.Forms.Button'
$CheckBox = 'System.Windows.Forms.CheckBox'
$ComboBox = 'System.Windows.Forms.ComboBox'
$ListBox = 'System.Windows.Forms.ListBox'
$ListView = 'System.Windows.Forms.ListView'
$CheckedListBox = 'System.Windows.Forms.CheckedListBox'
$RadioButton = 'System.Windows.Forms.RadioButton'
$TextBox = 'System.Windows.Forms.TextBox'
$RichTextBox = 'System.Windows.Forms.RichTextBox'
$Label = 'System.Windows.Forms.Label'
$Timer = 'System.Windows.Forms.Timer'
$ProgressBar = 'System.Windows.Forms.ProgressBar'

#endregion


#region Commands for Button / Label Creation

Function Add-Button($Name,$xsize,$ysize,$xpos,$ypos,$text){
New-Variable -Name $Name -Value $bname
$bname = New-Object $Button
$bname.Size = New-Object $Size($xsize,$ysize)
$bname.Location = New-Object $Location($xpos,$ypos)
$bname.Text = $text
$bname
}

Function Add-Label($Name,$xsize,$ysize,$xpos,$ypos,$text,$color,$Fixed3D){
New-Variable -Name $Name -Value $lname
$lname = New-Object $Label
$lname.Size = New-Object $Size($xsize,$ysize)
$lname.Location = New-Object $Location($xpos,$ypos)
If($Fixed3D -eq $null){$lname.BorderStyle = 'FixedSingle'}
$lname.Font = $Font_MainForm
$lname.TextAlign = 'MiddleCenter'
$lname.BackColor = 'Gray'
$lname.ForeColor = $color
$lname.Text = $text
$lname
}

Function Add-Background($Name,$xsize,$ysize,$xpos,$ypos,$color){
New-Variable -Name $Name -Value $bkgname
$bkgname = New-Object $PictureBox
$bkgname.Size = New-Object $Size($xsize,$ysize)
$bkgname.Location = New-Object $Location($xpos,$ypos)
$bkgname.BackColor = $color
$bkgname.BorderStyle = 'Fixed3D'
$bkgname.SendToBack()
$bkgname
}
#endregion


Function Edit-Date { 

$UpdateLog = [pscustomobject] @{
logname = 'staleusers'
rundate = $TimeStamp
ranby = $env:USERNAME}

$UpdateLog | Select logname,rundate,ranby | Export-csv -Path $FilePath_CSV -NoTypeInformation -Encoding UTF8 -Force

}

$MainForm = New-Object $Form 
$MainForm.Size = New-Object $Size(300,500)

Function Switch-Menu {
param([switch]$mmoff,
      [switch]$mmon,
      [string]$Menu)
    If($mmoff){$Script:HideMainMenu = 0}
    If($mmon){$Script:HideMainMenu = 1}
# Grouping Variables together
$MM_Staleusers = @($btn_StaleUsers,$lbl_StaleUsers_dateran,$lbl_StaleUsers_ranby,$bkg_StaleUsers)
$SM_StaleUsers = @($btn_StaleUsers_ReturnMM,$btn_StaleUsers_Gather,$list_StaleUsers_Users)

    If($HideMainMenu -eq 0){
        If($Menu -eq 'StaleUsers'){
            ForEach($Var in $MM_Staleusers){$MainForm.Controls.Remove($Var)}
            ForEach($Var in $SM_StaleUsers){$MainForm.Controls.Add($Var)}
            }
    }
    ElseIf($HideMainMenu -eq 1){
        ForEach($Var in $MM_Staleusers){$MainForm.Controls.Add($Var)}
        ForEach($Var in $SM_StaleUsers){$MainForm.Controls.Remove($Var)}    
    }
}

Function Change-Form {
Param([switch]$StaleUsers,
      [switch]$MainMenu)

If($StaleUsers){$MainForm.Size = New-Object $Size(700,700) ; Switch-Menu -mmoff -Menu StaleUsers}
If($MainMenu){$MainForm.Size = New-Object $Size(300,500) ; Switch-Menu -mmon}
}


#region - Loading Main Menu Buttons
<# Stale Users #>
$btn_StaleUsers = Add-Button btn_staleusers 240 50 20 20 "Stale Users" ; $MainForm.Controls.Add($btn_StaleUsers) # - Adds the Button
$btn_StaleUsers.Font = $Font_Primary
$btn_StaleUsers.Add_Click({Change-Form -StaleUsers})

$lbl_StaleUsers_dateran = Add-Label lbl_staleusers_dateran 240 30 20 80 "Last Ran : $log_staleusers_dateran" Yellow  ; $MainForm.Controls.Add($lbl_StaleUsers_dateran) # - Adds the Date Label
$lbl_StaleUsers_dateran.Font = $Font_Secondary

$lbl_StaleUsers_ranby = Add-Label lbl_staleusers_ranby 240 30 20 120 "Ran By : $log_staleusers_ranby" Yellow ; $MainForm.Controls.Add($lbl_StaleUsers_ranby) # - Adds the ran by Label
$lbl_StaleUsers_ranby.Font = $Font_Secondary

$bkg_StaleUsers = Add-Background bkg_staleusers 260 150 10 10 Gray ; $MainForm.Controls.Add($bkg_StaleUsers) # - Adds the Background

#endregion - End of Main Menu Buttons


#region - Stale Users Form
$btn_StaleUsers_ReturnMM = Add-Button btn_staleusers_returnmm 200 50 470 600 "Main Menu" ; $btn_StaleUsers_ReturnMM.Font = $Font_Primary # - Adds the Main Menu Button
$btn_StaleUsers_ReturnMM.Add_Click({Change-Form -MainMenu}) # - Returns to the Main Menu

$btn_StaleUsers_Gather = Add-Button btn_staleusers_gather 200 50 20 540 "GATHER USERS" ; $btn_StaleUsers_Gather.Font = $Font_Primary # - Adds the Gather users button
$btn_StaleUsers_Gather.Add_Click({}) # - Gathers all stale users

$list_StaleUsers_Users = New-Object $ListView ; $list_StaleUsers_Users.Size = New-Object $Size(200,200) ; $list_StaleUsers_Users.Location = New-Object $Location(10,10) # - Adds the list of Stale users
$clmA = New-Object System.Windows.Forms.ColumnHeader ; $list_StaleUsers_Users.Columns.Add($clmA)
    $clmA.Name = "Username" ; $clmA.Text = "Username" ; $clmA.Width = 100
$clmB = New-Object System.Windows.Forms.ColumnHeader ; $list_StaleUsers_Users.Columns.Add($clmB)
    $clmB.Name = "FName" ; $clmB.Text = "Full Name" ; $clmB.Width = 100


#endregion












#LAST LINE HERE
[System.Windows.Forms.Application]::Run($MainForm)
#