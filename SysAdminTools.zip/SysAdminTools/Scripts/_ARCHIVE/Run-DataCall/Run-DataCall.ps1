﻿
<#
 .Synopsis
  Automates any type of Datacall for users and computers 

 .Description
  Allows admins to quickly create datacalls for any user(s) and/or any machine(s)

 .Example
   Run-DataCall
   # Load the DataCall Script
   

#>

[void][System.Reflection.Assembly]::LoadWithPartialName('System.Windows.Forms')
[void][System.Reflection.Assembly]::LoadWithPartialName('System.Drawing')

<# Editable Variables #>
$PrimaryFolder = "\\newton\admin\SysAdmin Powershell Module\Scripts\-ARCHIVE\Run-DataCall"
$Folder_Exports = "$PrimaryFolder\Results\"
$Folder_Exports_Acccounts = "$PrimaryFolder\Results\Account Data Calls"
$Folder_Exports_Machines = "$PrimaryFolder\Results\Machine Data Calls"
$Folder_Exports_Printers = "$PrimaryFolder\Results\Printer Data Calls"
$Folder_Options = "$PrimaryFolder\Options\"
$Date = Get-Date -UFormat "%d-%B-%Y-%r" ; $Date = $Date.Replace(":","") ; $Script:Date = $Date.Replace(" ","")

<# Form Shortcut Variables #>
$Location = 'System.Drawing.Point'
$Size = 'System.Drawing.Size'
$Form = 'System.Windows.Forms.Form'
$PictureBox = 'System.Windows.Forms.PictureBox'
$Button = 'System.Windows.Forms.Button'
$CheckBox = 'System.Windows.Forms.CheckBox'
$ComboBox = 'System.Windows.Forms.ComboBox'
$ListBox = 'System.Windows.Forms.ListBox'
$ListView = 'System.Windows.Forms.ListView'
$CheckedListBox = 'System.Windows.Forms.CheckedListBox'
$RadioButton = 'System.Windows.Forms.RadioButton'
$TextBox = 'System.Windows.Forms.TextBox'
$RichTextBox = 'System.Windows.Forms.RichTextBox'
$Label = 'System.Windows.Forms.Label'
$Timer = 'System.Windows.Forms.Timer'
$ProgressBar = 'System.Windows.Forms.ProgressBar'
$GroupBox = 'System.Windows.Forms.GroupBox'
<##>

<# Font Sizes #>
$Font_Primary = [System.Drawing.Font]::new("Cosmic Sans", 11, [System.Drawing.FontStyle]::Bold)
$Font_Secondary = [System.Drawing.Font]::new("Cosmic Sans", 10, [System.Drawing.FontStyle]::Bold)
<##>

<# Array Variables #>
$acctypes = @('Admin Accounts','User Accounts','Service Accounts')
$machtypes = @('DC Servers','FP Servers','MBX Servers','SQL Servers','Workstations')
$machprops = @(Get-Content "$PrimaryFolder\Options\Mach_LessOptions.txt")
$machprops2 = @(Get-Content "$PrimaryFolder\Options\Mach_MoreOptions.txt")
$userprops = @(Get-Content "$PrimaryFolder\Options\User_LessOptions.txt")
$userprops2 = @(Get-Content "$PrimaryFolder\Options\User_MoreOptions.txt")
$printprops = @(Get-Content "$PrimaryFolder\Options\Print_LessOptions.txt")
$printprops2 = @(Get-Content "$PrimaryFolder\Options\Print_MoreOptions.txt")
$siteslist = @(Get-Content "$PrimaryFolder\Options\SiteList.txt")
<##>

#region <# Create Object Functions #>
Function Add-Label {Param([string]$name,[string]$xsize,[string]$ysize,[string]$xpos,[string]$ypos,[string]$text,[switch]$fixed3d)
    New-Variable -Name $name -Value $lname # - Creates the variable
    $lname = New-Object $Label ; $lname.Size = New-Object $Size($xsize,$ysize) ; $lname.Location = New-Object $Location($xpos,$ypos) # - Creates the label and size/location
    If($fixed3d){$lname.BorderStyle = 'Fixed3D'} # - Added the option for Fixed3D Border
    $lname.BackColor = 'Gray' # Sets the background color
    $lname.Font = $Font_Secondary ; $lname.TextAlign = 'MiddleCenter' ; $lname.Text = $text # - Sets the text options
    $lname    
}

Function Add-Button {Param([string]$name,[string]$xsize,[string]$ysize,[string]$xpos,[string]$ypos,[string]$text,[switch]$fixed3d)
    New-Variable -Name $name -Value $bname # - Creates the variable
    If($xsize -eq $null){$xsize = 100} If($ysize -eq $null){$ysize = 50} # - Makes sure a default size is set
    $bname = New-Object $Button ; $bname.Size = New-Object $Size($xsize,$ysize) ; $bname.Location = New-Object $Location($xpos,$ypos) # - Creates the button and size/location
    $bname.Text = $text # - Sets the button Text
    $bname
}

Function Add-CheckedListBox {Param([string]$name,[string]$xsize,[string]$ysize,[string]$xpos,[string]$ypos,[string]$text,[switch]$fixed3d)
    New-Variable -Name $name -Value $lname # - Creates the variable
    $lname = New-Object $CheckedListBox ; $lname.Size = New-Object $Size($xsize,$ysize) ; $lname.Location = New-Object $Location($xpos,$ypos) # - Creates the listbox and size/location
    $lname.Font = $Font_Primary # - Sets the listbox font
    $lname
}

Function Add-Background {Param([string]$name,[string]$xsize,[string]$ysize,[string]$xpos,[string]$ypos,[string]$color,[switch]$fixed3d)
    New-Variable -Name $name -Value $bkgname # - Creates the variable
    $bkgname = New-Object $PictureBox ; $bkgname.Size = New-Object $Size($xsize,$ysize) ; $bkgname.Location = New-Object $Location($xpos,$ypos) # - Creates the background and size/location
    $bkgname.BackColor = $color ; $bkgname.BorderStyle = 'Fixed3D' # - Sets the background color and border style
    $bkgname
}

Function Add-RadioButton {Param([string]$name,[string]$xsize,[string]$ysize,[string]$xpos,[string]$ypos,[string]$text,[switch]$fixed3d)
    New-Variable -Name $name -Value $rname # - Creates the Variable
    $rname = New-Object $RadioButton ; $rname.Size = New-Object $Size($xsize,$ysize) ; $rname.Location = New-Object $Location($xpos,$ypos) # - Creates the radio button and size/location
    $rname.Font = $Font_Secondary ; $rname.Text = $text # - Sets the radio button font and text
    $rname
}

Function Add-GroupRadio {Param([string]$name,[string]$xsize,[string]$ysize,[string]$xpos,[string]$ypos)
    New-Variable -Name $name -Value $grname # - Creates the Variable
    $grname = New-Object $GroupBox ; $grname.Size = New-Object $Size($xsize,$ysize) ; $grname.Location = New-Object $Location($xpos,$ypos) # - Creates the Group Box and size/location
    $grname
}

Function Add-CheckBox {Param([string]$name,[string]$xsize,[string]$ysize,[string]$xpos,[string]$ypos,[string]$text,[switch]$fixed3d)
    New-Variable -Name $name -Value $cname # - Creates the Variable
    $cname = New-Object $CheckBox ; $cname.Size = New-Object $Size($xsize,$ysize) ; $cname.Location = New-Object $Location($xpos,$ypos) # - Creates the checkbox and size/location
    $cname.Font = $Font_Secondary ; $cname.Text = $text # - Sets the checkbox font and text
    $cname
}
#endregion

#region <# Script Functions #>
Function Change-Form {
    Param([switch]$MainMenu, [switch]$Accounts, [switch]$Machines, [switch]$Printers)

    <# Object Arrays #>
    $Objects_MainMenu = @(
                        <# Temp #>$lbl_cs_printers,
                        <# Buttons #>$btn_Accounts,$btn_Machines,$btn_Printers,$btn_Printers,$btn_Exports,$btn_Exit,
                        <# Backgrounds #>$bkg_exit,$bkg_menu,$bkg_mainmenu
                        )
    $Objects_Accounts = @(
                        <# Buttons #>$btn_MainMenu,$btn_acc_run,$btn_acc_folder,$btn_acc_options,
                        <# Lists #>$list_acc_acctypes,$list_acc_userprops,$list_acc_sites,
                        <# Labels #>$lbl_acc_types,$lbl_acc_siteselect,$lbl_acc_userprops,
                        <# Radio Groups #>$gr_acc_types,$gr_acc_sites,$gr_acc_props,
                        <# Backgrounds #>$bkg_acc_types,$bkg_acc_siteselect,$bkg_acc_userprops,$bkg_acc_buttons
                        )
    $Objects_Machines = @(
                        <# Buttons #>$btn_MainMenu,$btn_mach_run,$btn_mach_folder,$btn_mach_options
                        <# Lists #>$list_mach_types,$list_mach_sites,$list_mach_props
                        <# Labels #>$lbl_mach_props,$lbl_mach_sites,$lbl_mach_types,
                        <# Radio Groups #>$gr_mach_types,$gr_mach_sites,$gr_mach_props,
                        <# Backgrounds #>$bkg_mach_types,$bkg_mach_sites,$bkg_mach_props,$bkg_mach_buttons
                        )
    $Objects_Printers = @()

    If($Accounts){
        ForEach($Var in $Objects_MainMenu){$MainForm.Controls.Remove($Var)}
        ForEach($Var in $Objects_Accounts){$MainForm.Controls.Add($Var)}
        $MainForm.Size = New-Object $Size(660,610)
        }
    If($Machines){
        ForEach($Var in $Objects_MainMenu){$MainForm.Controls.Remove($Var)}
        ForEach($Var in $Objects_Machines){$MainForm.Controls.Add($Var)}
        $Mainform.Size = New-Object $Size(660,610)
        }
    If($MainMenu){
        ForEach($Var in $Objects_Accounts){$MainForm.Controls.Remove($Var)}
        ForEach($Var in $Objects_Machines){$MainForm.Controls.Remove($Var)}
        ForEach($Var in $Objects_MainMenu){$MainForm.Controls.Add($Var)}
        $MainForm.Size = New-Object $Size(280,410)
        }
}

Function cmd-acc-options  {
    param([switch]$Accounts,[switch]$Sites,[Switch]$Properties,[switch]$Options)
    If($Accounts){
        If($rbtn_acc_all.Checked -eq $true){$list_acc_acctypes.Enabled = $false 
        For($i=0;$i -lt $list_acc_acctypes.items.Count ; $i++){$list_acc_acctypes.SetItemChecked($i,$false)}}
        Else{$list_acc_acctypes.Enabled = $true}
        }
    If($Sites){
        If($rbtn_acc_allsites.Checked -eq $true){$list_acc_sites.Enabled = $false ; 
            For($i=0;$i -lt $list_acc_sites.Items.Count ; $i++){$list_acc_sites.SetItemChecked($i,$false)}
            }Else{$list_acc_sites.Enabled = $true}
        }
   If($Properties){
        If($rbtn_acc_allprops.Checked -eq $true){$list_acc_userprops.Enabled = $false 
        For($i=0;$i -lt $list_acc_userprops.Items.Count ; $i++){$list_acc_userprops.SetItemChecked($i,$false)}
        }Else{$list_acc_userprops.Enabled = $true}
        }
    If($Options){
        If($list_acc_userprops.Items.Count -lt 50){$list_acc_userprops.DataSource = $userprops2 ; $btn_acc_options.Text = "Less Options"
            For($i=0;$i -lt $list_acc_userprops.Items.Count ; $i++){$list_acc_userprops.SetItemChecked($i,$false)}}
        ElseIf($list_acc_userprops.Items.Count -gt 50){$list_acc_userprops.DataSource = $userprops ; $btn_acc_options.Text = "More Options"
            For($i=0;$i -lt $list_acc_userprops.Items.Count ; $i++){$list_acc_userprops.SetItemChecked($i,$false)}}     
        }
}

Function cmd-mach-options {
    param([switch]$Machines,[switch]$Sites,[switch]$Properties,[switch]$Options)
    If($Machines){
        If($rbtn_mach_alltypes.Checked -eq $true){$list_mach_types.Enabled = $False
        For($i=0;$i -lt $list_mach_types.items.Count ; $i++){$list_mach_types.SetItemChecked($i,$false)}}
        Else{$list_mach_types.Enabled = $true}
        }
    If($Sites){
        If($rbtn_mach_allsites.Checked -eq $true){$list_mach_sites.Enabled = $false ;
        For($i=0;$i -lt $list_mach_sites.Items.Count ; $i++){$list_mach_sites.SetItemChecked($i,$false)}}
        Else{$list_mach_sites.Enabled = $true}
        }
    If($Properties){
        If($rbtn_mach_allprops.Checked -eq $true){$list_mach_props.Enabled = $false ;
        For($i=0;$i -lt $list_mach_props.items.Count ; $i++){$list_mach_props.SetItemChecked($i,$false)}}
        Else{$list_mach_props.Enabled = $true}
        }
    If($Options){
        If($list_mach_props.Items.Count -lt 50){$list_mach_props.DataSource = $machprops2 ; $btn_mach_options.Text = "Less Options"
            For($i=0;$i -lt $list_mach_props.Items.Count ; $i++){$list_mach_props.SetItemChecked($i,$false)}}
        ElseIf($list_mach_props.Items.Count -gt 50){$list_mach_props.DataSource = $machprops ; $btn_mach_options.Text = "More Options"
            For($i=0;$i -lt $list_mach_props.Items.Count ; $i++){$list_mach_props.SetItemChecked($i,$false)}}
        }
}

Function Begin-DataCall {Param([switch]$Accounts,[switch]$Machines,[switch]$Printers)
    If($Accounts){
        $Admin = 0;$Svc = 0;$User = 0 # Resetting the Account type selections
        $OUs = [System.Collections.Generic.List[System.String]]@() # Resetting the Site type selections
        $Properties = [System.Collections.Generic.List[System.String]]@() # Resettings the Properties type selections
        $ChkdSites = [System.Collections.Generic.List[System.String]]@() # Resetting list of checked sites
        $DNs = [System.Collections.Generic.List[System.String]]@()
        $Domain = "OU=sites,DC=newton,DC=pentagon,DC=mil"
        [String]$FileName = $env:USERNAME + $Script:Date


        <# Below is checking which Account type selections are made, starting with "All Accounts" #>
        If($rbtn_acc_all.Checked -eq $true){$Admin = 1 ; $User = 1 ; $Svc = 1}Else{
            <# Checking which account types are selected #>
            ForEach($i in $list_acc_acctypes.CheckedItems){
                If($i -eq 'Admin Accounts'){$Admin = 1}
                If($i -eq 'User Accounts'){$User = 1}
                If($i -eq 'Service Accounts'){$Svc = 1}
                }
            }

        <# Below is checking which sites selections are made, starting with "All Sites" #>
        If($rbtn_acc_allsites.Checked -eq $true){$OU = "*"}Else{
            ForEach($i in $list_acc_sites.CheckedItems){$ChkdSites.Add($i)}
            ForEach($i in $ChkdSites){If($i.Contains("_")){$new = $i -replace ".*_" ; $OUs.Add($new)}Else{$OUs.Add($i)}}
        }

        <# Below is checking which properties selections are made, starting with "All Properties" #>
        If($rbtn_acc_allprops.Checked -eq $true){$Properties.Add("*")}Else{
            ForEach($i in $list_acc_userprops.CheckedItems){$Properties.Add($i)}
            If($Properties -notmatch 'samaccountname'){$Properties.Add('samaccountname')}
        }

        <# Begin Gathering DN's of OUs #>
        If($rbtn_acc_allsites.Checked -eq $true){$DNs.Add("DC=newton,DC=pentagon,DC=mil")}Else{
            ForEach($i in $Ous){$Check = Get-ADOrganizationalUnit -SearchBase $Domain -Filter {Name -eq $i} | Select -expand DistinguishedName ; $DNs.Add($Check)}
        }
    
        <# Begin Collecting Data Based on Account Type Selection #>
        If($Admin -eq 1){ # Admin Accounts 
            $DN = "DC=newton,DC=pentagon,DC=mil"
            $dc_Admin = Get-ADUser -Properties * -SearchBase $DN -Filter {(Name -like "*-admin*") -or (Name -like "*- admin*")} | Select -Property $Properties | 
            Export-Csv -Path $Folder_Exports_Acccounts\AdminAccounts_$FileName.csv -NoTypeInformation -Encoding UTF8 -Force
        }
        If($User -eq 1){ # User Accounts
            ForEach($DN in $DNs){$dc_User = Get-ADUser -Properties * -SearchBase $DN -Filter{(Name -notlike "*-admin*") -and (Name -notlike "*- admin*") -and (Name -notlike "svc-*")} | Select -Property $Properties | 
            Export-Csv -Path $Folder_Exports_Acccounts\UserAccounts_$FileName.csv -NoTypeInformation -Encoding UTF8 -Append}
        }
        If($Svc -eq 1){ # Service Accounts
            $DN = "DC=newton,DC=pentagon,DC=mil"
            $dc_Svc = Get-ADUser -Properties * -SearchBase $DN -Filter{(Name -like "svc-*") -or (Name -like "svc -*")} | Select -Property $Properties | 
            Export-Csv -Path $Folder_Exports_Acccounts\SvcAccounts_$FileName.csv -NoTypeInformation -Encoding UTF8 -Force
        }  
    }

    If($Machines){
        $svr_DCs = 0;$svr_FPs = 0;$svr_MBXs = 0;$svr_SQLs = 0;$svr_WrkStations = 0 # - Resetting the Machine type selections
        $OUs = [System.Collections.Generic.List[System.String]]@() # - Resetting the Site type selections
        $Properties = [System.Collections.Generic.List[System.String]]@() # - Resettings the Properties type selections
        $ChkdSites = [System.Collections.Generic.List[System.String]]@() # - Resetting list of checked sites
        $DNs = [System.Collections.Generic.List[System.String]]@()
        $Domain = "OU=sites,DC=newton,DC=pentagon,DC=mil" 
        [String]$FileName = $env:USERNAME + $Script:Date
        
        <# Below is checking which Machine type selections are made, starting with "All Machines" #>    
        If($rbtn_mach_alltypes.Checked -eq $true){$DCs = 1 ; $FPs = 1 ; $MBXs = 1 ; $SQLs = 1 ; $WrkStations = 1} Else{
            <# Checking which account types are selected #>
            ForEach($i in $list_mach_types.CheckedItems){
                If($i -eq 'DC Servers'){$svr_DCs = 1}
                If($i -eq 'FP Servers'){$svr_FPs = 1}
                If($i -eq 'MBX Servers'){$svr_MBXs = 1}
                If($i -eq 'SQL Servers'){$svr_SQLs = 1}
                If($i -eq 'Workstations'){$svr_WrkStations = 1}
                }
            }
        <# Below is checking which sites selections are made, starting with "All Sites" #>
        If($rbtn_mach_allsites.Checked -eq $true){$OUs = "*"}Else{
            ForEach($i in $list_mach_allsites.CheckedItems){$ChkdSites.Add($i)}
            ForEach($i in $ChkdSites){If($i.Contains("_")){$new = $i -replace ".*_" ; $OUs.Add($new)}Else{$OUs.Add($i)}
            }
        }
        <# Below is checking which properties selections are made, starting with "All Properties" #>
        If($rbtn_mach_allprops.Checked -eq $true){$Properties.Add("*")}Else{
            ForEach($i in $list_mach_props.CheckedItems){$Properties.Add($i)}
            If($Properties -notmatch 'name'){$Properties.Add('name')}
        }
        <# Begin Gathering DN's of OUs #>
        If($rbtn_mach_allsites.Checked -eq $true){$DNs.Add("DC=newton,DC=pentagon,DC=mil")}Else{
            ForEach($i in $OUs){$Check = Get-ADOrganizationalUnit -SearchBase $Domain -Filter {Name -eq $i} | Select -expand DistinguishedName ; $DNs.Add($Check)
            }
        }
        <# Begin Collecting Data Based on Machine Type Selection #>
        If($svr_DCs -eq 1){ # - Domain Controllers
            ForEach($DN in $DNs){$dc_DCs = Get-ADComputer -Properties * -SearchBase $DN -Filter {Name -like "*DC0*"} | Select -Property $Properties |
            Export-Csv -Path $Folder_Exports_Machines\DomainControllers_$FileName.csv -NoTypeInformation -Encoding UTF8 -Append
            }
        }
        If($svr_FPs -eq 1){ # - File Print Servers
            ForEach($DN in $DNs){$dc_FPs = Get-ADComputer -Properties * -SearchBase $DN -Filter {Name -like "*FP0*"} | Select -Property $Properties | 
            Export-Csv -Path $Folder_Exports_Machines\FilePrintServers_$FileName.csv -NoTypeInformation -Encoding UTF8 -Append
            }
        }
        If($svr_MBXs -eq 1){ # - Mailbox Servers
            ForEach($DN in $DNs){$dc_MBXs = Get-ADComputer -Properties * -SearchBase $DN -Filter {Name -like "*MBX0*"} | Select -Property $Properties |
            Export-Csv -Path $Folder_Exports_Machines\MBXservers_$FileName.csv -NoTypeInformation -Encoding UTF8 -Append
            }
        }
        If($svr_SQLs -eq 1){ # - SQL Servers
            ForEach($DN in $DNs){$dc_SQLs = Get-ADComputer -Properties * -SearchBase $DN -Filter {Name -like "*SQL0*"} | Select -Property $Properties |
            Export-Csv -Path $Folder_Exports_Machines\SQLservers_$FileName.csv -NoTypeInformation -Encoding UTF8 -Append
            }
        }
        If($svr_WrkStations -eq 1){ # - Workstations
            ForEach($DN in $DNs){$dc_WrkStations = Get-ADComputer -Properties * -SearchBase $DN -Filter {(OperatingSystem -notlike "*Server*") -and (Name -notlike "*VDI*") -and (Name -notlike "MSTR")} | Select -Property $Properties |
            Export-Csv -Path $Folder_Exports_Machines\Workstations_$FileName.csv -NoTypeInformation -Encoding UTF8 -Append
            }
        }        
    }    
}
#endregion

#region <# MainMenu Configuration #>
<# MainMenu Form #>
$MainForm = New-Object $Form ; $MainForm.Size = New-Object $Size(280,410) ; $MainForm.FormBorderStyle = 'Fixed3D'
<# $MainForm.ControlBox = $false #> ; $MainForm.Text = "Main Menu"
<##>

<# COMING SOON TO (TO BE REMOVED) #> 
$lbl_cs_printers = Add-Label lbl_cs_printers 120 15 65 180 "(Coming Soon)" x ; $lbl_cs_printers.BackColor = 'LightYellow' ; $lbl_cs_printers.ForeColor = 'Gray' ; $MainForm.Controls.Add($lbl_cs_printers)
<##>

<# Buttons #>
$btn_Accounts = Add-Button btn_accounts 200 50 30 30 "Account Data Call" ; $btn_Accounts.Font = $Font_Primary ; $MainForm.Controls.Add($btn_Accounts) # - User Data Call Button
$btn_Machines = Add-Button btn_machines 200 50 30 90 "Machine Data Call" ; $btn_Machines.Font = $Font_Primary ; $MainForm.Controls.Add($btn_Machines) # - Machine Data Call Button
$btn_Printers = Add-Button btn_printers 200 50 30 150 "Printer Data Call" ; $btn_Printers.Font = $Font_Primary ; $MainForm.Controls.Add($btn_Printers) # - Printer Data Call Button
$btn_Exports = Add-Button btn_exports 200 50 30 230 "Results Folder" ; $btn_Exports.Font = $Font_Primary ; $MainForm.Controls.Add($btn_Exports) # - Results Folder Button
$btn_Exit = Add-Button btn_exit 200 50 30 290 "Exit Script" ; $btn_Exit.Font = $Font_Primary ; $MainForm.Controls.Add($btn_Exit) # - Close Script Button
    <# Button Modifications #>
    $btn_Accounts.Add_Click({Change-Form -Accounts}) ; $btn_Machines.Add_Click({Change-Form -Machines}) ; $btn_Printers.Add_Click({}) # - Action on Button Click
    $btn_Exports.Add_Click({Invoke-Item -Path $Folder_Exports}) ; $btn_Exit.Add_Click({$MainForm.Dispose()}) # - Action on Button Click
    $btn_Machines.BackColor = 'LightGreen' ; $btn_Printers.BackColor = 'LightYellow' ; $btn_Exports.BackColor = 'Lavender' ; $btn_Exit.BackColor = 'Pink' ; $btn_Accounts.BackColor = 'LightBlue' # - BackColor Changes
    $btn_Printers.Enabled = $false # - Disabling button
    <##>
<##>

<# Backgrounds #>
$bkg_exit = Add-Background bkg_exit 220 130 20 220 'DarkGray' ; $bkg_exit.SendToBack() ; $MainForm.Controls.Add($bkg_exit) # - Background For Exit Button
$bkg_menu = Add-Background bkg_menu 220 220 20 20 'DarkGray' ; $bkg_menu.SendToBack() ; $MainForm.Controls.Add($bkg_menu) # - Background for Menu Items
$bkg_mainmenu = Add-Background bkg_mainmenu 250 360 5 5 'Black' ; $bkg_mainmenu.SendToBack() ; $MainForm.Controls.Add($bkg_mainmenu) # - Background for main menu
<##>
#endregion

#region <# Accounts Data Call Form Configuration #>
<# Buttons #>
$btn_MainMenu = Add-Button btn_mainmenu 100 50 520 500 "Main Menu" ; $btn_MainMenu.Font = $Font_Primary ; $btn_MainMenu.BackColor = 'Pink' # - Button for returning to main menu
$btn_acc_run = Add-Button btn_acc_run 200 50 20 500 "Begin Data Call" ; $btn_acc_run.Font = $Font_Primary ; $btn_acc_run.BackColor = 'LightGreen' # - Button for beginning DataCall
$btn_acc_reset = Add-Button btn_acc_reset 120 50 230 500 "Reset Form" ; $btn_acc_reset.Font = $Font_Primary ; $btn_acc_reset.BackColor = 'LightYellow' # - Button for reseting form
$btn_acc_folder = Add-Button btn_acc_folder 100 50 410 500 "Results Folder" ; $btn_acc_folder.Font = $Font_Primary ; $btn_acc_folder.BackColor = 'LightBlue' # - Button for opening Accounts results folder
$btn_acc_options = Add-Button btn_acc_options 120 30 450 245 "More Options" ; $btn_acc_options.Font = $Font_Primary ; $btn_acc_options.BackColor = 'LightYellow' # - Button for showing more/less options
    <# Button Modifications #>
    $btn_acc_options.Add_Click({cmd-acc-options -Options}) ; $btn_acc_folder.Add_Click({Invoke-Item -Path $Folder_Exports_Acccounts}) # - Actions on button click
    $btn_MainMenu.Add_Click({Change-Form -MainMenu}) ; $btn_acc_reset.Add_Click({}) ; $btn_acc_run.Add_Click({Begin-DataCall -Accounts}) # - Actions on button click
    <##>
<##>

<# Checked Listboxes #>
$list_acc_acctypes = Add-CheckedListBox list_acc_acctypes 600 30 20 40 ; $list_acc_acctypes.Font = $Font_Secondary ; $list_acc_acctypes.DataSource = $acctypes # - Checked Listbox for Account Types
$list_acc_userprops = Add-CheckedListBox list_acc_userprops 600 210 20 278 ; $list_acc_userprops.Font = $Font_Secondary ; $list_acc_userprops.DataSource = $userprops # - Checked Listbox for User Properties
$list_acc_sites = Add-CheckedListBox list_acc_sites 600 120 20 110 ; $list_acc_sites.Font = $Font_Secondary ; $list_acc_sites.DataSource = $siteslist # - Checked Listbox for Site Selection
    <# Checked Listbox Modifications #>
    $list_acc_sites.MultiColumn = $true ; $list_acc_acctypes.MultiColumn = $true ; $list_acc_userprops.MultiColumn = $true # - Enabling the multicolumn setting
    $list_acc_sites.CheckOnClick = $true ; $list_acc_acctypes.CheckOnClick = $true ; $list_acc_userprops.CheckOnClick = $true # - Enabling the check on click setting
    $list_acc_sites.ColumnWidth = 225 ; $list_acc_acctypes.ColumnWidth = 150 ; $list_acc_userprops.ColumnWidth = 225 # - Setting the column Width
    <##>
<##>

<# Labels #>
$lbl_acc_types = Add-Label lbl_acc_types 120 30 20 12 "Account Type :" x ; $lbl_acc_types.Font = $Font_Primary ; $lbl_acc_types.BackColor = 'LightGray' # - Account Types Label
$lbl_acc_siteselect = Add-Label lbl_acc_siteselect 120 30 20 82 "Site Selection :" x ; $lbl_acc_siteselect.Font = $Font_Primary ; $lbl_acc_siteselect.BackColor = 'LightGray' # - Site Selection Label
$lbl_acc_userprops = Add-Label lbl_acc_userprops 150 30 20 245 "Property Selection :" x ; $lbl_acc_userprops.Font = $Font_Primary ; $lbl_acc_userprops.BackColor = 'LightGray' # - User Properties Label
<##>

<# Radio Buttons #>
$rbtn_acc_all = Add-RadioButton rbtn_acc_all 120 30 0 0 "All Accounts" ; $rbtn_acc_all.BackColor = 'LightGray' # - Radio Button for All Accounts
$rbtn_acc_custom = Add-RadioButton rbtn_acc_custom 140 30 120 0 "Custom Selection"  ; $rbtn_acc_custom.BackColor = 'LightGray' # - Radio button for Custom accounts
$rbtn_acc_sitecustom = Add-RadioButton rbtn_acc_sitecustom 140 30 140 0 "Custom Selection" ; $rbtn_acc_sitecustom.BackColor = 'LightGray' # - Radio Button for custom sites
$rbtn_acc_allsites = Add-RadioButton rbtn_acc_allsites 140 30 0 0 "Select All Sites" ; $rbtn_acc_allsites.BackColor = 'LightGray' # - Radio Button for All Sites
$rbtn_acc_allprops = Add-RadioButton rbtn_acc_allprops 100 30 0 0 "Select All" ; $rbtn_acc_allprops.BackColor = 'LightGray' # - Radio Button for All Properties
$rbtn_acc_propcustom = Add-RadioButton rbtn_acc_propcustom 140 30 100 0 "Custom Selection" ; $rbtn_acc_propcustom.BackColor = 'LightGray' # - Radio Button for Custom Properties
    <# Radio Button Modifications #>
    $rbtn_acc_all.Add_CheckedChanged({cmd-acc-options -Accounts}) ; $rbtn_acc_allsites.Add_CheckedChanged({cmd-acc-options -Sites}) ; $rbtn_acc_allprops.Add_CheckedChanged({cmd-acc-options -Properties}) # Actions for check changed
    $rbtn_acc_all.Checked = $true ; $rbtn_acc_allsites.Checked = $true ; $rbtn_acc_allprops.Checked = $true # Setting Checkstate to TRUE
    <##>
<##>

<# Radio Groups #>
$gr_acc_types = Add-GroupRadio gr_acc_acctypes 260 30 150 14 ; $gr_acc_types.Controls.AddRange(@($rbtn_acc_all,$rbtn_acc_custom)) # - Radio Group for Account types
$gr_acc_sites = Add-GroupRadio gr_acc_sites 280 30 150 84 ; $gr_acc_sites.Controls.AddRange(@($rbtn_acc_allsites,$rbtn_acc_sitecustom)) # - Radio Group for Site selection
$gr_acc_props = Add-GroupRadio gr_acc_props 240 30 180 248 ; $gr_acc_props.Controls.AddRange(@($rbtn_acc_allprops,$rbtn_acc_propcustom)) # - Radio Group for Property Selection
<##>

<# Backgrounds #>
$bkg_acc_types = Add-Background bkg_acc_types 620 60 10 10 'LightGray' ; $bkg_acc_types.SendToBack() # - Background for Account Types 
$bkg_acc_siteselect = Add-Background bkg_acc_sites 620 155 10 75 'LightGray' ; $bkg_acc_siteselect.SendToBack() # - Background for Site Selection 
$bkg_acc_userprops = Add-Background bkg_acc_userprops 620 245 10 240 'LightGray' ; $bkg_acc_userprops.SendToBack() # - Background for User Properties 
$bkg_acc_buttons = Add-Background bkg_acc_buttons 620 70 10 490 'Gray' ; $bkg_acc_buttons.SendToBack() # - Background for buttons 
<##>
#endregion

#region <# Machines Data Call Form Configuration #>
<# Buttons #>
$btn_mach_run = Add-Button btn_mach_run 200 50 20 500 "Begin Data Call" ; $btn_mach_run.Font = $Font_Primary ; $btn_mach_run.BackColor = 'LightGreen' # - Button for Running DataCall
$btn_mach_folder = Add-Button btn_mach_folder 100 50 410 500 "Results Folder" ; $btn_mach_folder.Font = $Font_Primary ; $btn_mach_folder.BackColor = 'LightBlue' # - Button for Machine Exports Folder
$btn_mach_options = Add-Button btn_mach_options 120 30 450 260 "More Options" ; $btn_mach_options.Font = $Font_Primary ; $btn_mach_options.BackColor = 'LightYellow' # - Button for Less/More Options
    <# Button Modifications #>
    $btn_mach_run.Add_Click({Begin-DataCall -Machines}) ; $btn_mach_folder.Add_Click({Invoke-Item -Path $Folder_Exports_Machines}) ; $btn_mach_options.Add_Click({cmd-mach-options -Options}) # - Actions for button clicks
    <##>
<##>

<# Checked List Boxes #>
$list_mach_types = Add-CheckedListBox list_mach_types 600 40 20 40 ; $list_mach_types.Font = $Font_Secondary ; $list_mach_types.DataSource = $machtypes # - Checked Listbox for Machine Types
$list_mach_sites = Add-CheckedListBox list_mach_sites 600 120 20 125 ; $list_mach_sites.Font = $Font_Secondary ; $list_mach_sites.DataSource = $siteslist # - Checked Listbox for Site Selection
$list_mach_props = Add-CheckedListBox list_mach_props 600 190 20 293 ; $list_mach_props.Font = $Font_Secondary ; $list_mach_props.DataSource = $machprops # - Checked Listbox for Machine Properties
    <# Listbox Modificaitons #>
    $list_mach_types.CheckOnClick = $true ; $list_mach_sites.CheckOnClick = $true ; $list_mach_props.CheckOnClick = $true # - Enabling Check on Click
    $list_mach_Types.MultiColumn = $true ; $list_mach_sites.MultiColumn = $true ; $list_mach_props.MultiColumn = $true # - Enabling Multicolumn
    $list_mach_types.ColumnWidth = 150 ; $list_mach_sites.ColumnWidth = 225 ; $list_mach_props.ColumnWidth = 225 # - Setting Column Width
    <##>
<##>

<# Labels #>
$lbl_mach_props = Add-Label lbl_mach_props 150 30 20 260 "Property Selection :" x ; $lbl_mach_props.Font = $Font_Primary ; $lbl_mach_props.BackColor = 'LightGray' # - Label for Machine Properties
$lbl_mach_sites = Add-Label lbl_mach_sites 120 30 20 97 "Site Selection :" x ; $lbl_mach_sites.Font = $Font_Primary ; $lbl_mach_sites.BackColor = 'LightGray' # - Label for Site Selection
$lbl_mach_types = Add-Label lbl_mach_types 120 30 20 12 "Machine Type :" x ; $lbl_mach_types.Font = $Font_Primary ; $lbl_mach_types.BackColor = 'LightGray' # - Label for Machine Types
<##>

<# Radio Buttons #>
$rbtn_mach_alltypes = Add-RadioButton rbtn_mach_alltypes 120 30 0 0 "All Machines" ; $rbtn_mach_alltypes.BackColor = 'LightGray' # - All Types
$rbtn_mach_custmtypes = Add-RadioButton rbtn_mach_custmtypes 140 30 120 0 "Custom Selection" ; $rbtn_mach_custmtypes.BackColor = 'LightGray' # - Custom Types
$rbtn_mach_allsites = Add-RadioButton rbtn_mach_allsites 140 30 0 0 "Select All Sites" ; $rbtn_mach_allsites.BackColor = 'LightGray' # - Custom Sites
$rbtn_mach_custmsites = Add-RadioButton rbtn_mach_custmsites 140 30 140 0 "Custom Selection" ; $rbtn_mach_custmsites.BackColor = 'LightGray' # - Custom Sites 
$rbtn_mach_allprops = Add-RadioButton rbtn_mach_allprops 100 30 0 0 "Select All" ; $rbtn_mach_allprops.BackColor = 'LightGray' # - All Properties
$rbtn_mach_custmprops = Add-RadioButton rbtn_mach_custmprops 140 30 100 0 "Custom Selection" ; $rbtn_mach_custmprops.BackColor = 'LightGray' # - Custom Properties
    <# Radio Button Modifications #>
    $rbtn_mach_alltypes.Add_CheckedChanged({cmd-mach-options -Machines}) ; $rbtn_mach_allsites.Add_CheckedChanged({cmd-mach-options -Sites}) ; $rbtn_mach_allprops.Add_CheckedChanged({cmd-mach-options -Properties}) # - Executes function on check/uncheck
    $rbtn_mach_alltypes.Checked = $true ; $rbtn_mach_allsites.Checked = $true ; $rbtn_mach_allprops.Checked = $true # - Enables radio button from startup
    <##>
<##>

<# Radio Groups #>
$gr_mach_types = Add-GroupRadio gr_mach_types 260 30 150 14 ; $gr_mach_types.Controls.AddRange(@($rbtn_mach_alltypes,$rbtn_mach_custmtypes)) # - Radio Group for Machine types
$gr_mach_sites = Add-GroupRadio gr_mach_sites 280 30 150 99 ; $gr_mach_sites.Controls.AddRange(@($rbtn_mach_allsites,$rbtn_mach_custmsites)) # - Radio Group for Site selection
$gr_mach_props = Add-GroupRadio gr_mach_props 240 30 180 263 ; $gr_mach_props.Controls.AddRange(@($rbtn_mach_allprops,$rbtn_mach_custmprops)) # - Radio Group for Property Selection
<##>
 
<# Backgrounds  #>
$bkg_mach_types = Add-Background bkg_mach_types 620 75 10 10 'LightGray' ; $bkg_mach_types.SendToBack() # - Background for Machine Types
$bkg_mach_sites = Add-Background bkg_mach_sites 620 155 10 90 'LightGray' ; $bkg_mach_sites.SendToBack() # - Background for Site Selection
$bkg_mach_props = Add-Background bkg_mach_props 620 230 10 255 'LightGray' ; $bkg_mach_props.SendToBack() # - Background for Machine Properties
$bkg_mach_buttons = Add-Background bkg_mach_buttons 620 70 10 490 'Gray' ; $bkg_mach_buttons.SendToBack() # - Background for buttons
<##>    
#endregion

<# Process upon start of script #>
[System.Windows.Forms.Application]::Run($MainForm) 