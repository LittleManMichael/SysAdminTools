﻿

<#
 .Synopsis
  Automates any type of Datacall for users and computers 

 .Description
  Allows admins to quickly create datacalls for any user(s) and/or any machine(s)

 .Example
   Run-DataCall
   # Load the DataCall Script
   

#>

[void][System.Reflection.Assembly]::LoadWithPartialName('System.Windows.Forms')
[void][System.Reflection.Assembly]::LoadWithPartialName('System.Drawing')

#region VARIABLES

## Primary Variables ##
$Network = 'DC=newton, DC=pentagon, DC=mil'
$LessOptions = Get-Content -Path "\\newton\admin\SysAdmin Powershell Module\Scripts\Run-DataCall\LessOptions.txt"
$MoreOptions = Get-Content -Path "\\newton\admin\SysAdmin Powershell Module\Scripts\Run-DataCall\MoreOptions.txt"
$Break = ""

## Array Variables ##
$CheckedItems = [System.Collections.Generic.List[System.String]] @()
$Script:UserList = [System.Collections.Generic.List[System.String]] @()
$MissingData = [System.Collections.Generic.List[System.String]] @()

## Font Configurations ##
$Font_Primary = [System.Drawing.Font]::new("Cosmic Sans", 12, [System.Drawing.FontStyle]::Bold)
$Font_Secondary = [System.Drawing.Font]::New("Cosmic Sans", 12)
$Font_MainForm = [System.Drawing.Font]::New("Cosmic Sans", 10)

## Text Variables ##
$txt_Welcome = "==== Welcome to the Data Call Mega Script! ====
Please be sure to follow the guidelines listed below! 
--------------------------------------------------------------------
- Select a chosen object to collect data from.
- Fill in your required items to be collected.
- Begin the process and wait patiently while it works.
- Finish off with options for your output! "

## WinForm Shortcut Variables ##
$Location = 'System.Drawing.Point'
$Size = 'System.Drawing.Size'
$Form = 'System.Windows.Forms.Form'
$PictureBox = 'System.Windows.Forms.PictureBox'
$Button = 'System.Windows.Forms.Button'
$CheckBox = 'System.Windows.Forms.CheckBox'
$ComboBox = 'System.Windows.Forms.ComboBox'
$ListBox = 'System.Windows.Forms.ListBox'
$CheckedListBox = 'System.Windows.Forms.CheckedListBox'
$RadioButton = 'System.Windows.Forms.RadioButton'
$TextBox = 'System.Windows.Forms.TextBox'
$RichTextBox = 'System.Windows.Forms.RichTextBox'
$Label = 'System.Windows.Forms.Label'
$Timer = 'System.Windows.Forms.Timer'
$ProgressBar = 'System.Windows.Forms.ProgressBar'

#endregion

#region MainForm Configuraiton

## MainForm ##
$MainForm = New-Object $Form
$MainForm.Size = New-Object $Size(350,440)
$MainForm.ControlBox = $false
$MainForm.FormBorderStyle = 'Fixed3D'
$MainForm.Text = "Data Call Mega-Script"

## Welcome Label ##
$lbl_Welcome = New-Object $Label
$lbl_Welcome.Size = New-Object $Size(330,110)
$lbl_Welcome.Location = New-Object $Location(10,10)
$lbl_Welcome.Font = $Font_MainForm
$lbl_Welcome.Text = "$txt_Welcome"
$MainForm.Controls.Add($lbl_Welcome)

## Close Butotn ##
$btn_Close = New-Object $Button
$btn_Close.Size = New-Object $Size(200,50)
$btn_Close.Location = New-Object $Location(70,330)
$btn_Close.Add_Click({$MainForm.Close()})
$btn_Close.Text = "Exit"
$MainForm.Controls.Add($btn_Close)

## User Script Button ##
$btn_Users = New-Object $Button
$btn_Users.Size = New-Object $Size(200,50)
$btn_Users.Location = New-Object $Location(70,140)
$btn_Users.Add_Click({Get-UserData})
$btn_Users.Text = "User Data"
$MainForm.Controls.Add($btn_Users)

## Computer Script Button ##
$btn_Computers = New-Object $Button
$btn_Computers.Size = New-Object $Size(200,50)
$btn_Computers.Location = New-Object $Location(70,200)
$btn_Computers.Add_Click({})
$btn_Computers.Enabled = $false
$btn_Computers.Text = "Computer Data (Coming Soon)"
$MainForm.Controls.Add($btn_Computers)

#endregion


Function Get-UserData {
#region DataForm Configuraiton

## Primary Form ##
$DataCallForm = New-Object $Form
$DataCallForm.Size = New-Object $Size(610,650)
$DataCallForm.ControlBox = $false
$DataCallForm.FormBorderStyle = 'Fixed3D'
$DataCallForm.Text = "User Data Call"

## Close Button ##
$btn_Close = New-Object $Button
$btn_Close.Size = New-Object $Size(100,50)
$btn_Close.Location = New-Object $Location(480,550)
$btn_Close.Add_Click({$MainForm.Show() ; $DataCallForm.Dispose()})
$btn_Close.Text = "Exit"
$DataCallForm.Controls.Add($btn_Close)

## Run Script Button ##
$btn_RunScript = New-Object $Button
$btn_RunScript.Size = New-Object $Size(100,50)
$btn_RunScript.Location = New-Object $Location(350,550)
$btn_RunScript.Add_Click({Run-Script})
$btn_RunScript.Text = "Begin Data Call"
$DataCallForm.Controls.Add($btn_RunScript)

## Clear/Reset Button ##
$btn_Reset = New-Object $Button
$btn_Reset.Size = New-Object $Size(100,50)
$btn_Reset.Location = New-Object $Location(220,550)
$btn_Reset.Add_Click({})
$btn_Reset.Text = "Clear / Reset"
$DataCallForm.Controls.Add($btn_Reset)

## More Options Button ##
$btn_Options = New-Object $Button
$btn_Options.Size = New-Object $Size(120,50)
$btn_Options.Location = New-Object $Location(50,190)
$btn_Options.Add_Click({Change-Options})
$btn_Options.Text = "More Options -->"
$DataCallForm.Controls.Add($btn_Options)

## All Account Radio Button ##
$radio_All = New-Object $RadioButton
$radio_All.Size = New-Object $Size(150,30)
$radio_All.Location = New-Object $Location(30,40)
$radio_All.Checked = $true
$radio_All.Text = "All Accounts"
$DataCallForm.Controls.Add($radio_All)

## Admin Only Accounts Radio Button ##
$radio_AdminOnly = New-Object $RadioButton
$radio_AdminOnly.Size = New-Object $Size (150,30)
$radio_AdminOnly.Location = New-Object $Location(30,70)
$radio_AdminOnly.Text = "Admin Accounts Only"
$DataCallForm.Controls.Add($radio_AdminOnly)

## User Accounts Only Radio Button ##
$radio_UserOnly = New-Object $RadioButton
$radio_UserOnly.Size = New-Object $Size(150,30)
$radio_UserOnly.Location = New-Object $Location(30,100)
$radio_UserOnly.Text = "User Accounts Only"
$DataCallForm.Controls.Add($radio_UserOnly)

## Service Accounts Only Radio Button ##
$radio_ServiceOnly = New-Object $RadioButton
$radio_ServiceOnly.Size = New-Object $Size(150,30)
$radio_ServiceOnly.Location = New-Object $Location(30,130)
$radio_ServiceOnly.Text = "Service Accounts Only"
$DataCallForm.Controls.Add($radio_ServiceOnly)

## Search Criteria Label ##
$lbl_SearchCriteria = New-Object $Label
$lbl_SearchCriteria.Size = New-Object $Size(190,25)
$lbl_SearchCriteria.Location = New-Object $Location(20,10)
$lbl_SearchCriteria.BackColor = 'LightGray'
$lbl_SearchCriteria.BorderStyle = 'Fixed3D'
$lbl_SearchCriteria.TextAlign = 'MiddleCenter'
$lbl_SearchCriteria.Font = $Font_Primary
$lbl_SearchCriteria.Text = "Search Criteria"
$DataCallForm.Controls.Add($lbl_SearchCriteria)

## Property List Label ##
$lbl_PropertyList = New-Object $Label
$lbl_PropertyList.Size = New-Object $Size(350,25)
$lbl_PropertyList.Location = New-Object $Location(225,10)
$lbl_PropertyList.BackColor = 'LightGray'
$lbl_PropertyList.BorderStyle = 'Fixed3D'
$lbl_PropertyList.TextAlign = 'MiddleCenter'
$lbl_PropertyList.Font = $Font_Primary
$lbl_PropertyList.Text = "Property Selection"
$DataCallForm.Controls.Add($lbl_PropertyList)

## Finished Info Label ##
$lbl_FinishInfo = New-Object $Label
$lbl_FinishInfo.Size = New-Object $Size(350,25)
$lbl_FinishInfo.Location = New-Object $Location(225,265)
$lbl_FinishInfo.BackColor = 'LightGray'
$lbl_FinishInfo.BorderStyle = 'Fixed3D'
$lbl_FinishInfo.TextAlign = 'MiddleCenter'
$lbl_FinishInfo.Font = $Font_Primary
$lbl_FinishInfo.Text = "Data Call Results"
$DataCallForm.Controls.Add($lbl_FinishInfo)

## Export Options Label ##
$lbl_Export = New-Object $Label
$lbl_Export.Size = New-Object $Size(190,25)
$lbl_Export.Location = New-Object $Location(20,265)
$lbl_Export.BackColor = 'LightGray'
$lbl_Export.BorderStyle = 'Fixed3D'
$lbl_Export.TextAlign = 'MiddleCenter'
$lbl_Export.Font = $Font_Primary
$lbl_Export.Text = "Export Options"
$DataCallForm.Controls.Add($lbl_Export)

## Finished Info - Total Users Label ##
$lbl_TotalUsers = New-Object $Label
$lbl_TotalUsers.Size = New-Object $Size(130,20)
$lbl_TotalUsers.Location = New-Object $Location(225,290)
$lbl_TotalUsers.Font = $Font_MainForm
$lbl_TotalUsers.Text = "Total Users : "
$DataCallForm.Controls.Add($lbl_TotalUsers)

## Finished Info - Users Missing Data Label ##
$lbl_UsersMissing = New-Object $Label
$lbl_UsersMissing.Size = New-Object $Size(250,20)
$lbl_UsersMissing.Location = New-Object $Location(360,290)
$lbl_UsersMissing.Font = $Font_MainForm
$lbl_UsersMissing.Text = "Total Users Missing Data : "
$DataCallForm.Controls.Add($lbl_UsersMissing)

## Finished Info - Property Selected Label ##
$lbl_EmptyData = New-Object $Label
$lbl_EmptyData.Size = New-Object $Size(130,20)
$lbl_EmptyData.Location = New-Object $Location(225,320)
$lbl_EmptyData.Font = $Font_MainForm
$lbl_EmptyData.Text = "Property Selected : "
$DataCallForm.Controls.Add($lbl_EmptyData)

## Property Selected - Data ##
$Data_Property = New-Object $Label
$Data_Property.Size = New-Object $Size(200,20)
$Data_Property.Location = New-Object $Location(360,320)
$Data_Property.Font = $Font_MainForm
$Data_Property.BackColor = 'Transparent'
$Data_Property.BorderStyle = 'Fixed3D'
$Data_Property.TextAlign = 'MiddleCenter'
$Data_Property.Text = ""
$DataCallForm.Controls.Add($Data_Property)

## Finished Info - User Selected Label ##
$lbl_SelectedUser = New-Object $Label
$lbl_SelectedUser.Size = New-Object $Size(100,20)
$lbl_SelectedUser.Location = New-Object $Location(225,350)
$lbl_SelectedUser.Font = $Font_MainForm
$lbl_SelectedUser.Text = "Selected User : "
$DataCallForm.Controls.Add($lbl_SelectedUser)

## User Selected - Data Label ##
$Data_User = New-Object $Label
$Data_User.Size = New-Object $Size(200,20)
$Data_User.Location = New-Object $Location(360,350)
$Data_User.Font = $Font_MainForm
$Data_User.BackColor = 'Transparent'
$Data_User.BorderStyle = 'Fixed3D'
$Data_User.TextAlign = 'MiddleCenter'
$Data_User.Text = ""
$DataCallForm.Controls.Add($Data_User)

## Finished Info - User's Property Value Label ##
$lbl_UserValue = New-Object $Label
$lbl_UserValue.Size = New-Object $Size(120,20)
$lbl_UserValue.Location = New-Object $Location(225,380)
$lbl_UserValue.Font = $Font_MainForm
$lbl_UserValue.Text = "Value of Property : "
$DataCallForm.Controls.Add($lbl_UserValue)

## User's Property - Data ##
$Data_Value = New-Object $Label
$Data_Value.Size = New-Object $Size(200,20)
$Data_Value.Location = New-Object $Location(360,380)
$Data_Value.Font = $Font_MainForm
$Data_Value.BackColor = 'Transparent'
$Data_Value.BorderStyle = 'Fixed3D'
$Data_Value.TextAlign = 'MiddleCenter'
$Data_Value.Text = ""
$DataCallForm.Controls.Add($Data_Value)

## Select Only Missing Machines CheckBox ##
$chkbox_OnlyMissing = New-Object $CheckBox
$chkbox_OnlyMissing.Size = New-Object $Size(320,20)
$chkbox_OnlyMissing.Location = New-Object $Location(235,410)
$chkbox_OnlyMissing.Checked = $false
$chkbox_OnlyMissing.Font = $Font_MainForm
$chkbox_OnlyMissing.Text = "Show ONLY Machines Missing Data"
$DataCallForm.Controls.Add($chkbox_OnlyMissing)

## Select All CheckBox ##
$chkbox_SelectAll = New-Object $CheckBox
$chkbox_SelectAll.Size = New-Object $Size(150,20)
$chkbox_SelectAll.Location = New-Object $Location(235,230)
$chkbox_SelectAll.Checked = $false
$chkbox_SelectAll.Add_CheckStateChanged({Select-All})
$chkbox_SelectAll.Font = $Font_MainForm
$chkbox_SelectAll.Text = "Select All Properties"
$DataCallForm.Controls.Add($chkbox_SelectAll)

## List of User Properties List Box ##
$List_UserProps = New-Object $CheckedListBox
$List_UserProps.Size = New-Object $Size(360,210)
$List_UserProps.Location = New-Object $Location(220,35)
$List_UserProps.Font = $Font_Secondary
$List_UserProps.Add_SelectedIndexChanged({Get-Properties})
$List_UserProps.Items.AddRange($LessOptions)
$List_UserProps.CheckonClick = $true
$DataCallForm.Controls.Add($List_UserProps)

## List of Selected Properties Box ##
$List_SelectedProps = New-Object $ListBox
$List_SelectedProps.Size = New-Object $Size(170,100)
$List_SelectedProps.Location = New-Object $Location(225,440)
$List_SelectedProps.Add_SelectedIndexChanged({Show-PropertyData})
$DataCallForm.Controls.Add($List_SelectedProps)

## List of Users Missing Data Box ##
$List_UsersMissing = New-Object $ListBox
$List_UsersMissing.Size = New-Object $Size(170,100)
$List_UsersMissing.Location = New-Object $Location(400,440)
$List_UsersMissing.Add_SelectedIndexChanged({Get-MissingValue})
$DataCallForm.Controls.Add($List_UsersMissing)

#endregion

Function Change-Options {
$CheckedItems.Clear()
If($btn_Options.Text.Contains("More")){$List_UserProps.Items.Clear() ; $List_UserProps.Items.AddRange($MoreOptions) ; $btn_Options.Text = "Less Options -->"}
ElseIf($btn_Options.Text.Contains("Less")){$List_UserProps.Items.Clear() ; $List_UserProps.Items.AddRange($LessOptions) ; $btn_Options.Text = "More Options -->"}
}

Function Get-Properties {
$CheckedItems.Clear()
ForEach($Item in $List_UserProps.CheckedItems){$CheckedItems.Add($Item)}
If($CheckedItems.Contains('SamAccountName')){}Else{$CheckedItems.Add('SamAccountName')}
}

Function Run-Script { 
$DataCallForm.Hide() #Hiding the Form, to Avoid freezing.
$Script:UserList.Clear()
$lbl_TotalUsers.Text = "0"
$i = 0 #Counter
$md = 0 #Missing Data Counter
$List_UsersMissing.Items.Clear()

If($radio_All.Checked -eq $true){$AccountType = 'SamAccountName -like "*"'}
ElseIf($radio_AdminOnly.Checked -eq $true){$AccountType = 'SamAccountName -like "*-admin*"'}
ElseIf($radio_UserOnly.Checked -eq $true){$AccountType = '(SamAccountName -notlike "*-admin*") -and (SamAccountName -notlike "svc-*") -and (SamAccountName -notlike "*-*")'}
ElseIf($radio_ServiceOnly.Checked -eq $True){$AccountType = 'SamAccountName -like "svc-*"'}

$Gather = Get-ADUser -Filter $AccountType -Properties * | Select -Property $CheckedItems | ForEach{
$i++ ; If($Percent -gt 98){$Percent = 99}Else{$Percent = $i / 50 * 100} ; Write-Progress -Activity "Gathering Total Users....$Percent%" -Status "Total Users = $i" -PercentComplete $Percent ;
$Script:UserList += $_ }

#Add Total user count to the information box.
$lbl_TotalUsers.Text = "Total Users : " + $UserList.Count

#Adding Selected Properties to Info box List
$List_SelectedProps.Items.AddRange($CheckedItems)

#Gathering Empty Data Variables
ForEach($u in $UserList){ ForEach($p in $CheckedItems){
If($u.$p -eq $null -or ($u.$p -eq " ")){$y = $true}}
If($y -eq $true){$md++} ; $y = $false}

#Add Total User missing data count.
$lbl_UsersMissing.Text = "Total Users Missing Data : " + $md

$DataCallForm.Show() #Restore form visibility
}

Function Show-PropertyData {
$p = $List_SelectedProps.SelectedItem #Select the Property
$List_UsersMissing.Items.Clear()

#Check to see if to Gather ALL Users or just users missing data
If($chkbox_OnlyMissing.Checked -eq $true){
#Go Through List of Users to Gather Missing Users missing Data.
ForEach($u in $UserList){
If($u.$p -eq $null -or ($u.$p -eq " ")){$List_UsersMissing.Items.Add($u.SamAccountName)}
If($List_UsersMissing.Items.Count -eq 0){$List_UsersMissing.Items.Add("Nothing to Show")}Else{}
     }}
Else{
#Go Through and Gather Every User
ForEach($u in $UserList){$List_UsersMissing.Items.Add($u.SamAccountName)}
If($List_UsersMissing.Items.Count -eq 0){$List_UsersMissing.Items.Add("Nothing to Show")}Else{}
}
}

Function Get-MissingValue {
#Get ahold of selected user
$i = $List_UsersMissing.SelectedItem
$p = $List_SelectedProps.SelectedItem

$Data_Property.Text = $p
$Data_User.Text = $i
ForEach($u in $UserList){If($u.SamAccountName -eq $i){$v = $u.$p ; $Data_Value.Text = $v}Else{}}

#Writing Property Selected
Write-Host "Property Selected : " -no -f DarkGray ; Write-Host $p -f Yellow
#Writing SamAccountName
Write-Host "User Selected : " -no -f DarkGray ; Write-Host $i -f Yellow
#Writing Property Value
Write-Host "Value Output : " -no -f DarkGray ; Write-Host $v -f Yellow
Write-Host " " 
} 

Function Select-All {

#Check Checkstate and either select all or deselect all
If($chkbox_SelectAll.Checked -eq $true){For($i = 0; $i -lt $List_UserProps.Items.Count ; $i++){ $List_UserProps.SetItemChecked($i,$true)} ; $CheckedItems.Clear() ; ForEach($Item in $List_UserProps.CheckedItems){$CheckedItems.Add($Item)}}
ElseIf($chkbox_OnlyMissing.Checked -eq $false){For($i = 0; $i -lt $List_UserProps.Items.Count ; $i++){ $List_UserProps.SetItemChecked($i,$false)} ; $CheckedItems.Clear()}

}

#region BACKGROUND LAYERS
## Search Criteria BackGround ##
$bdr_SearchCriteria = New-Object $PictureBox
$bdr_SearchCriteria.Size = New-Object $Size(200,165)
$bdr_SearchCriteria.Location = New-Object $Location(15,5)
$bdr_SearchCriteria.BackColor = 'Transparent'
$bdr_SearchCriteria.BorderStyle = 'Fixed3D'
$DataCallForm.Controls.Add($bdr_SearchCriteria)

## Property List Background ##
$bdr_PropertyList = New-Object $PictureBox
$bdr_PropertyList.Size = New-Object $Size(360,250)
$bdr_PropertyList.Location = New-Object $Location(220,5)
$bdr_PropertyList.BackColor = 'Transparent'
$bdr_PropertyList.BorderStyle = 'Fixed3D'
$DataCallForm.Controls.Add($bdr_PropertyList)

## Info of Finish Background ##
$bdr_FinishInfo = New-Object $PictureBox
$bdr_FinishInfo.Size = New-Object $Size(360,280)
$bdr_FinishInfo.Location = New-Object $Location(220,260)
$bdr_FinishInfo.BackColor = 'Transparent'
$bdr_FinishInfo.BorderStyle = 'Fixed3D'
$DataCallForm.Controls.Add($bdr_FinishInfo)

## Export Options Background ##
$bdr_Export = New-Object $PictureBox
$bdr_Export.Size = New-Object $Size(200,290)
$bdr_Export.Location = New-Object $Location(15,260)
$bdr_Export.BackColor = 'Transparent'
$bdr_Export.BorderStyle = 'Fixed3D'
$DataCallForm.Controls.Add($bdr_Export)


#endregion

## Open the DataCall Form
$MainForm.Hide() ; $DataCallForm.ShowDialog()

}



[System.Windows.Forms.Application]::Run($MainForm)

