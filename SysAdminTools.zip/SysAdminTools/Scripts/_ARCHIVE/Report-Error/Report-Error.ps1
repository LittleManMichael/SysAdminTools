

<#
 .Synopsis
  Report an error OR bug that is being caused by any script or module created by the SysAdmins Script Team. 

 .Description
  Allows the Administrator to create a report that describes an error or bug pertaining to a script and/or module created by the SysAdmins Script Team.

 .Example
    Report-Error
    # Runs the Script with the standard protocols.
   
#>

# Windows Form Implements and Variables
[void][System.Reflection.Assembly]::LoadWithPartialName('System.Windows.Forms')
[void][System.Reflection.Assembly]::LoadWithPartialName('System.Drawing')
$Font_Primary = [System.Drawing.Font]::new("Cosmic Sans", 11, [System.Drawing.FontStyle]::Bold)
$Font_Secondary = [System.Drawing.Font]::new("Cosmic Sans", 11)
$Location = 'System.Drawing.Point'
$Size = 'System.Drawing.Size'
$Form = 'System.Windows.Forms.Form'
$PictureBox = 'System.Windows.Forms.PictureBox'
$Button = 'System.Windows.Forms.Button'
$CheckBox = 'System.Windows.Forms.CheckBox'
$ComboBox = 'System.Windows.Forms.ComboBox'
$ListBox = 'System.Windows.Forms.ListBox'
$ListView = 'System.Windows.Forms.ListView'
$CheckedListBox = 'System.Windows.Forms.CheckedListBox'
$RadioButton = 'System.Windows.Forms.RadioButton'
$TextBox = 'System.Windows.Forms.TextBox'
$RichTextBox = 'System.Windows.Forms.RichTextBox'
$Label = 'System.Windows.Forms.Label'
$Timer = 'System.Windows.Forms.Timer'
$ProgressBar = 'System.Windows.Forms.ProgressBar'
$GroupBox = 'System.Windows.Forms.GroupBox'


# Editable Variables
$ReportsFolder = "\\newton\admin\SysAdmin Powershell Module\Support\Reports"
$User = $env:USERNAME
$reportemailsubject = ""
$YN = @('Yes','No','Not Sure','Did Not Troubleshoot')
$ScriptList = Get-Content "\\newton\admin\SysAdmin Powershell Module\Active-Scripts.txt"




Function Get-Error{
    [string]$Script = $list_q1.SelectedItem
    $geterror = ""
    $errorcnt = 0
    ForEach($E in $Error){
        If($E.CategoryInfo -match $Script){
            $geterror = $E.Exception.Message
            $tb_desc.AppendText("`n`n ERROR IMPORTER : $geterror")
            $errorcnt++
            }
        Else{}
    }
    
    If($errorcnt -eq 0){$geterror = "No Errors Found" ; $tb_desc.AppendText("`n`n ERROR IMPORTER : $geterror")}Else{}        
}

Function Send-Report{
    [string]$scname = $list_q1.SelectedItem
    [string]$restype = $list_q2.SelectedItem
    [string]$details = $tb_desc.Text
    $smtpsettings = @{
	    To =  "msprous@newton.pentagon.mil"
	    From = "$User@newton.pentagon.mil"
	    Subject = "Error found on $scname"
	    SmtpServer = "N020MBX01.newton.pentagon.mil"
	    }
    [string]$Body = "Error with script $scname `nDid the admin resolve? - $restype `nDetails : $details"

    Send-MailMessage @smtpsettings -Body $Body -Encoding ([System.Text.Encoding]::UTF8)
    $btn_Send.Enabled = $false ; $btn_Send.Text = "REPORT SENT" ; $btn_Send.BackColor = 'LightGreen'
}

Function Reset-Form{
    If($btn_Send.Enabled -eq $false){$btn_Send.Enabled = $true ; $btn_Send.Text = "Send Report" ; $btn_Send.BackColor = 'LightGray'}
    $tb_desc.Clear()
}

$MainForm = New-Object $Form ; $MainForm.Size = New-Object $Size(590,410) ; $MainForm.FormBorderStyle = 'Fixed3D' ; $MainForm.Text = "Error Reporter"

$lbl_q1 = New-Object $Label ; $lbl_q1.Size = New-Object $Size(230,30) ; $lbl_q1.Location = New-Object $Location(20,20) ; $MainForm.Controls.Add($lbl_q1)
$lbl_q1.Font = $Font_Secondary ; $lbl_q1.Text = "Which Script gave the Error?"
$list_q1 = New-Object $ComboBox ; $list_q1.Size = New-Object $Size (230,100) ; $list_q1.Location = New-Object $Location(20,50) ; $MainForm.Controls.Add($list_q1)
$list_q1.Items.AddRange($ScriptList) ; $list_q1.font = $Font_Secondary ; $list_q1.SelectedIndex = 0

$lbl_q2 = New-Object $Label ; $lbl_q2.Size = New-Object $Size(270,30) ; $lbl_q2.Location = New-Object $Location(280,20) ; $MainForm.Controls.Add($lbl_q2)
$lbl_q2.Font = $Font_Secondary ; $lbl_q2.Text = "Were you able to resolve the Error?"
$list_q2 = New-Object $ComboBox ; $list_q2.Size = New-Object $Size (230,100) ; $list_q2.Location = New-Object $Location(280,50) ; $MainForm.Controls.Add($list_q2)
$list_q2.Items.AddRange($YN) ; $list_q2.font = $Font_Secondary

$lbl_q3 = New-Object $Label ; $lbl_q3.Size = New-Object $Size (500,50) ; $lbl_q3.Location = New-Object $Location(20,85) ; $MainForm.Controls.Add($lbl_q3)
$lbl_q3.Font = $Font_Secondary ; $lbl_q3.Text = "Please describe what the error caused and if it affected the completion of the script. You can copy and paste the error if you want or you can import it if you're using the same powershell session"
$tb_desc = New-Object $RichTextBox ; $tb_desc.Size = New-Object $Size(530,150) ; $tb_desc.Location = New-Object $Location(20,140) ; $MainForm.Controls.Add($tb_desc)
$tb_desc.Font = $Font_Secondary

$btn_import = New-Object $Button ; $btn_import.Size = New-Object $Size(200,50) ; $btn_import.Location = New-Object $Location(20,300) ; $MainForm.Controls.Add($btn_import)
$btn_import.Font = $Font_Primary ; $btn_import.Text = "Import Error" ; $btn_import.BackColor = "LightGray" ; $btn_import.Add_Click({Get-Error})

$btn_Send = New-Object $Button ; $btn_Send.Size = New-Object $Size(200,50) ; $btn_Send.Location = New-Object $Location(350,300) ; $MainForm.Controls.Add($btn_Send)
$btn_Send.Font = $Font_Primary ; $btn_Send.Text = "Send Report" ; $btn_Send.BackColor = "LightGray" ; $btn_Send.Add_Click({Send-Report})

$btn_reset = New-Object $Button ; $btn_reset.Size = New-Object $Size(80,40) ; $btn_reset.Location = New-Object $Location(245,305) ; $MainForm.Controls.Add($btn_reset)
$btn_reset.Font = $Font_Primary ; $btn_reset.Text = "RESET" ; $btn_reset.BackColor = "LightYellow" ; $btn_reset.Add_Click({Reset-Form})

<# Process upon start of script #>
[System.Windows.Forms.Application]::Run($MainForm) 