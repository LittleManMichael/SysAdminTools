
[void][System.Reflection.Assembly]::LoadWithPartialName('System.Windows.Forms')
[void][System.Reflection.Assembly]::LoadWithPartialName('System.Drawing')
$RequestFolder = "\\newton\admin\SysAdmin Powershell Module\Support\Requests"

# Settings for Mail
$smtpsettings = @{
	To =  "msprous@newton.pentagon.mil"
	From = "$User@newton.pentagon.mil"
	Subject = "$reportemailsubject - $now"
	SmtpServer = "N020MBX01.newton.pentagon.mil"
	}

# Font Configurations 
$Font_Primary = [System.Drawing.Font]::new("Cosmic Sans", 12, [System.Drawing.FontStyle]::Bold)
$Font_Secondary = [System.Drawing.Font]::New("Cosmic Sans", 12)
$Font_MainForm = [System.Drawing.Font]::New("Cosmic Sans", 10)

# Variables for WinForms
$Size = 'System.Drawing.Size'
$Location = 'System.Drawing.Point'
$Form = 'System.Windows.Forms.Form'
$Button = 'System.Windows.Forms.Button'
$RichTextbox = 'System.Windows.Forms.RichTextBox'
$ComboBox = 'System.Windows.Forms.ComboBox'
$CheckedListBox = 'System.Windows.Forms.CheckedListBox'
$Label = 'System.Windows.Forms.Label'
$PictureBox = 'System.Windows.Forms.PictureBox'
#
Function Add-Test {Param([string]$name,[string]$xsize,[string]$ysize,[string]$xpos,[string]$ypos,[string]$text,[switch]$fixed3d)
    New-Variable -Name $name -Value $lname # - Creates the variable
    $lname = New-Object $Label ; $lname.Size = New-Object $Size($xsize,$ysize) ; $lname.Location = New-Object $Location($xpos,$ypos) # - Creates the label and size/location
    If($fixed3d){$lname.BorderStyle = 'Fixed3D'} # - Added the option for Fixed3D Border
    $lname.BackColor = 'Gray' # Sets the background color
    $lname.Font = $Font_Secondary ; $lname.TextAlign = 'MiddleCenter' ; $lname.Text = $text # - Sets the text options
    $lname

    
}



# Form Configuration
$MainForm = New-Object $Form
$MainForm.Size = New-Object $Size(700,300)
$MainForm.FormBorderStyle = 'Fixed3D'
$MainForm.Text = "Request Form"

$lbl_test = Add-Test -name lbl_test -xsize 100 -ysize 50 -xpos 500 -ypos 200 -text "TESTING" ; $MainForm.Controls.Add($Script:lbl_test)

# Label for List of Scrpts
$Lbl_ScriptsList = New-Object $Label
$Lbl_ScriptsList.Size = New-Object $Size(210,40)
$Lbl_ScriptsList.Location = New-Object $Location(20,10)
$Lbl_ScriptsList.Font = $Font_Primary
$Lbl_ScriptsList.Text = "Please select the script(s) you would like to update"
$MainForm.Controls.Add($Lbl_ScriptsList)

# Label of Message Box
$lbl_MessageBox = New-Object $Label
$lbl_MessageBox.Size = New-Object $Size(290,20)
$lbl_MessageBox.Location = New-Object $Location(250,10)
$lbl_MessageBox.Font = $Font_Primary
$lbl_MessageBox.Text = "Please enter what you are requesting"
$MainForm.Controls.Add($lbl_MessageBox)

# Label Message Box Secondary
$lbl_submessagebox = New-Object $Label
$lbl_submessagebox.Size = New-Object $Size(260,20)
$lbl_submessagebox.Location = New-Object $Location (250,30)
$lbl_submessagebox.Font = $Font_MainForm
$lbl_submessagebox.Text = "Be sure to be as detailed as possible."
$MainForm.Controls.Add($lbl_submessagebox)

# List of Scripts
$Scripts = Get-Content -Path "\\newton\admin\SysAdmin Powershell Module\Active-Scripts.txt"
$List_Scripts = New-Object $CheckedListBox
$List_Scripts.Size = New-Object $Size(200,200)
$List_Scripts.Location = New-Object $Location(20,50)
$List_Scripts.Items.AddRange($Scripts)
$List_Scripts.CheckOnClick = $true
$MainForm.Controls.Add($List_Scripts)

# Line Border
$bdr_Line = New-Object $PictureBox
$bdr_Line.Size = New-Object $Size(1,240)
$bdr_Line.Location = New-Object $Location(234,10)
$bdr_Line.BackColor = 'DarkGray'
$MainForm.Controls.Add($bdr_Line)

# Message Box
$MessageBox = New-Object $RichTextbox
$MessageBox.Size = New-Object $Size(300,200)
$MessageBox.Location = New-Object $Location(250,50)
$MessageBox.Font = $Font_Secondary
$MainForm.Controls.Add($MessageBox)

# Submit Button
$btn_Submit = New-Object $Button
$btn_Submit.Size = New-Object $Size(100,40)
$btn_Submit.Location = New-Object $Location(570,210)
$btn_Submit.Text = "Submit Request"
$btn_Submit.Font = $Font_Primary
$MainForm.Controls.Add($btn_Submit)

# Begin Script
[System.Windows.Forms.Application]::Run($MainForm)

